#include "contiki.h"
#include "net/routing/routing.h"
#include "net/ipv6/simple-udp.h"
#include "sys/log.h"

#define LOG_MODULE "Leader Election"
#define LOG_LEVEL LOG_LEVEL_INFO

#define UDP_PORT 1234
#define ELECTION_INTERVAL (10 * CLOCK_SECOND)
#define NUM_NODES 10 // Define the number of nodes

typedef struct {
    int id;
    // Add other node-specific information if needed
} node_t;

node_t nodes[NUM_NODES]; // Define the nodes array

static struct simple_udp_connection udp_conn;
static int node_id; // Unique ID for each node
static int leader_id = -1; // Current leader ID

void start_election();
int is_leader_alive();
int is_leader_low_energy();

PROCESS(leader_election_process, "Leader Election Process");
AUTOSTART_PROCESSES(&leader_election_process);

static void udp_rx_callback(struct simple_udp_connection *c,
                            const uip_ipaddr_t *sender_addr,
                            uint16_t sender_port,
                            const uip_ipaddr_t *receiver_addr,
                            uint16_t receiver_port,
                            const uint8_t *data,
                            uint16_t datalen) {
    char msg[datalen + 1];
    memcpy(msg, data, datalen);
    msg[datalen] = '\0';

    if (strcmp(msg, "ELECTION") == 0) {
        if (node_id > sender_addr->u8[15]) {
            char ok_msg[] = "OK";
            simple_udp_sendto(&udp_conn, ok_msg, sizeof(ok_msg), sender_addr);
            start_election();
        }
    } else if (strcmp(msg, "OK") == 0) {
        // Wait for coordinator message
    } else if (strcmp(msg, "COORDINATOR") == 0) {
        leader_id = sender_addr->u8[15];
        LOG_INFO("New Leader: %d\n", leader_id);
    }
}

void start_election() {
    uip_ipaddr_t destination_ipaddr;
    char election_msg[] = "ELECTION";

    for (int i = 0; i < NUM_NODES; i++) {
        if (nodes[i].id > node_id) {
            uip_ip6addr(&destination_ipaddr, 0xfe80, 0, 0, 0, 0x0212, 0x7401, 0x0001, nodes[i].id); // Set appropriate address
            simple_udp_sendto(&udp_conn, election_msg, sizeof(election_msg), &destination_ipaddr);
        }
    }
}

int is_leader_alive() {
    // Implement the logic to check if the leader is alive
    return 1; // Placeholder return value
}

int is_leader_low_energy() {
    // Implement the logic to check if the leader is low on energy
    return 0; // Placeholder return value
}

PROCESS_THREAD(leader_election_process, ev, data) {
    PROCESS_BEGIN();

    simple_udp_register(&udp_conn, UDP_PORT, NULL, UDP_PORT, udp_rx_callback);

    while (1) {
        static struct etimer et;
        etimer_set(&et, ELECTION_INTERVAL);

        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));

        // Check if current leader is alive or low on energy
        if (!is_leader_alive() || is_leader_low_energy()) {
            start_election();
        }

        etimer_reset(&et);
    }

    PROCESS_END();
}