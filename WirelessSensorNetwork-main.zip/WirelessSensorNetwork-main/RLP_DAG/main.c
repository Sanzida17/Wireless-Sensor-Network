#include "net/routing/rpl-classic/rpl.h"
#include "net/routing/rpl-classic/rpl-private.h"
#include "net/routing/rpl-classic/rpl-conf.h"
#include "contiki.h"
#include "net/netstack.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/uip-ds6.h"
#include "sys/log.h"

#define LOG_MODULE "RPL-Root"
#define LOG_LEVEL LOG_LEVEL_INFO

PROCESS(rpl_root_process, "RPL Root Process");
AUTOSTART_PROCESSES(&rpl_root_process);

PROCESS_THREAD(rpl_root_process, ev, data)
{
  static struct etimer periodic_timer;
  uip_ipaddr_t ipaddr;
  rpl_dag_t *dag;

  PROCESS_BEGIN();

  /* Set global IPv6 address for the root */
  uip_ip6addr(&ipaddr, 0xfd00, 0, 0, 0, 0x212, 0x4b00, 0x616, 0xfcc);
  
  /* Set this node as the root of a new DAG */
  rpl_set_root(RPL_DEFAULT_INSTANCE, &ipaddr);
  
  /* Get the created DAG */
  dag = rpl_get_any_dag();
  
  /* Set the prefix for the DAG */
  uip_ip6addr(&ipaddr, 0xfd00, 0, 0, 0, 0, 0x212, 0x4b00, 0x616); //uip_ip6addr(&addr, 0xaaaa, 0, 0, 0, 0, 0, 0, to);
  rpl_set_prefix(dag, &ipaddr, 64);

  LOG_INFO("RPL DAG root initialized\n");

  /* Set a periodic timer to send DIOs */
  etimer_set(&periodic_timer, CLOCK_SECOND * 60);

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));
    etimer_reset(&periodic_timer);
    
    LOG_INFO("DAG root still running\n");
    /* Optionally: Add code to monitor or manage the DAG */
  }

  PROCESS_END();
}