#include <stdint.h>
#include "sys/node-id.h"
#include "sys/log.h"
#include "sys/ctimer.h"
#include "net/nullnet/nullnet.h"
#include "net/netstack.h"
#include "sht11-sensor.h"
#include "lib/random.h"
#include "sys/energest.h"
#include "os/storage/cfs/cfs.h"
#include "dev/button-sensor.h"

#define LOG_MODULE "MAS"
#define LOG_LEVEL LOG_LEVEL_DBG

#define ENERGY_STARTINGPOINT 100   // Starting energy
#define ENERGY_THRESHOLD_LEVEL  20 // Minimum energy to participate ENERGY_THRESHOLD_LEVEL MIN_ENERGY
#define ENERGY_LOSS 1      // Energy loss per interval
#define MIN_RANDOM 30
#define MAX_RANDOM 100

#define STATUS_COORDINATOR  "COORDINATOR"
#define STATUS_MEMBER  "MEMBER"
#define STATUS_ORPHAN  "ORPHAN"
#define ENERGY_FILE  "energy.txt" // Underscore makes the file only able to write to it and not append... weird...
#define ELECTION_FILE  "election.txt"
#define COORDINATOR_FILE  "coordinator.txt"
#define DATA_FILE  "data.txt"

#define LEADER 1

typedef enum {
    COORDINATOR,
    MEMBER,
    ORPHAN,
} NodeType;

typedef enum {
    PRESENT,
    ABSENT,
} CoordinatorStatus;

typedef enum {
    INIT_NODE_TYPE,
    IDLE,
    ENERGY_LOW,
    ENERGY_GONE,
} NodeState;

typedef enum {
    ELECTION_NONE,         // No election is currently happening
    ELECTION_IN_PROGRESS,      // An election is currently underway
} ElectionStatus;

typedef enum {
    NONE,
    OK,
} MessageStatus;

typedef enum {
    MSG_START_ELECTION,
    MSG_START_COLLECTION_ELECTION_DATA,
    MSG_HEARTBEAT,
    MSG_OK,
    MSG_COORDINATOR,
    MSG_GATHER_DATA,
    MSG_MESSAGE_COUNT,
} MSG;

typedef struct {
    uint8_t id;
    uint8_t energy;
} node_t;

typedef struct {
    uint16_t id;
    linkaddr_t address;
    CoordinatorStatus status;
} coordinator_node_t;

typedef struct {
    struct etimer *timer;
    struct ctimer *e_timer;
    clock_time_t heartbeat;
} timer_data_t;

typedef struct {
    float temperature;
    float humidity;
} measurements_t;

typedef struct {
    uint8_t sender_id;
    uint8_t sender_energy;
} sender_node_data_t;

typedef struct {
    uint8_t type;
    sender_node_data_t sender_node_data;
    measurements_t measurements;
    uint8_t message_count;
} msg_t;

void log_scaled_value(const char *label, float scaled_value, const char *unit);
bool has_timeout_occurred(clock_time_t last_heartbeat, uint16_t timeout_seconds);
void handle_election_timeout(node_t *node);
void decrease_energy(node_t *node);
bool is_low_energy(node_t *node);
void input_callback(const void *data, uint16_t len, const linkaddr_t *src, const linkaddr_t *dest);
void handle_node_state_change(coordinator_node_t* node);
void start_election();
float convertToCelsius(float temperature);
float convertToHumidity(float humidity);
void log_energy_data(const char *filename);
void log_election_energy_data(const char *filename, const char *state);
void log_gathering_data(float temperature, float humidity);
void print_file_contents(const char *filename);
void print_msg(const msg_t *msg);
void print_scaled_value(const char *label, float scaled_value, const char *unit);
void reset_counts_callback(void *ptr);
void report_gathering_callback(void *ptr);
static unsigned long to_seconds(uint64_t time);

PROCESS(bully_process, "Bully");
AUTOSTART_PROCESSES(&bully_process);

coordinator_node_t coordinator_node;
timer_data_t timer_data;
measurements_t measurements;
msg_t msg;
node_t node;

ElectionStatus election_status = ELECTION_NONE;
MessageStatus message_status = NONE;
NodeType node_type;
NodeState node_state;

static struct etimer timer;
static struct ctimer e_timer;
static linkaddr_t dest_addr;
static uint16_t local_message_count = 0;
static uint16_t total_message_count = 0;
static uint8_t total_data_count = 0;
static struct ctimer gathering_count_reset_timer;
static struct ctimer count_reset_timer;
static uint8_t log_gathering_data_count = 0;
static uint8_t election_number = 0;
static uint8_t on_going_election = 1;

static bool node_dead = false;
static bool election_coordinator_found = true;
static bool got_election_msg = false;

PROCESS_THREAD(bully_process, ev, data) {
    PROCESS_BEGIN();

    random_init((unsigned short)(clock_time() + node_id));
    coordinator_node.status = ABSENT;
    nullnet_set_input_callback(input_callback);

    if (node_id >= 255) {
        node.id = (uint8_t)(node_id / 256);
    } else {
        node.id = node_id;
    }
    LOG_INFO("Node id: %d\n", node.id);

    node.energy = MIN_RANDOM + (random_rand() % (MAX_RANDOM - MIN_RANDOM + 1));
    node_state = INIT_NODE_TYPE;

    timer_data.timer = &timer;
    timer_data.e_timer = &e_timer;
    timer_data.heartbeat = clock_time();
    SENSORS_ACTIVATE(sht11_sensor);
    SENSORS_ACTIVATE(button_sensor);
    energest_init();

    etimer_set(&timer, CLOCK_SECOND * 6);

    while(1) {
        etimer_set(timer_data.timer, CLOCK_SECOND * 5);
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(timer_data.timer));

        switch (node_state)
        {
        case INIT_NODE_TYPE:
            if (node_id == 1) {
                node_type = COORDINATOR;
                node_state = IDLE;
                coordinator_node.status = PRESENT;
            } else {
                node_type = ORPHAN;
                node_state = IDLE;
            }
            break;

        case IDLE:
            switch (node_type)
            {
            case COORDINATOR:
                LOG_INFO("COORDINATOR... (E:%d)\n", node.energy);
                log_energy_data(COORDINATOR_FILE); 

                if (node.energy < ENERGY_THRESHOLD_LEVEL) {
                    node_state = ENERGY_LOW;
                }

                msg_t s = {
                    .type = MSG_HEARTBEAT,
                    .sender_node_data = { .sender_id = node.id, .sender_energy = node.energy }
                };
                printf("Sending heartbeat message\n");

                nullnet_buf = (uint8_t *)&s;
                nullnet_len = sizeof(s);
                NETSTACK_NETWORK.output(NULL); // Broadcast
                break;

            case MEMBER:
                LOG_INFO("MEMBER... (E:%d)\n", node.energy);
                log_energy_data(ENERGY_FILE);

                if (has_timeout_occurred(timer_data.heartbeat, 10)) {
                    coordinator_node.status = ABSENT;
                    handle_node_state_change(&coordinator_node);
                }

                if (node.id == coordinator_node.id) {// Need to make sure the node has a different id than the coordinator. So reassign the id and renew random init.. This is due to link layer issue with 2 identical bits
                    random_init((unsigned short)clock_time());
                    node.id = 1 + (random_rand() % (254 - 0 + 1));
                    LOG_INFO("New node id: %d, has the same as the leader\n", node.id);
                } 

                measurements.temperature = convertToCelsius(sht11_sensor.value(SHT11_SENSOR_TEMP));
                measurements.humidity = convertToHumidity(sht11_sensor.value(SHT11_SENSOR_HUMIDITY));

                // We should send this message to the coordinator and why?
                msg_t msg_gather_data = {
                    .type = MSG_GATHER_DATA,
                    .sender_node_data = { .sender_id = node.id, .sender_energy = node.energy },
                    .measurements = measurements
                };
                printf("Sending gather data message\n");

                nullnet_buf = (uint8_t *)&msg_gather_data;
                nullnet_len = sizeof(msg_gather_data);
                NETSTACK_NETWORK.output(&dest_addr);
                

                break;

            case ORPHAN:
                LOG_INFO("Orphan... (E:%d)\n", node.energy);
                log_energy_data(ENERGY_FILE);
                handle_node_state_change(&coordinator_node);
                if (node.id == coordinator_node.id) {// Need to make sure the node has a different id than the coordinator. So reassign the id and renew random init
                    random_init((unsigned short)clock_time());
                    node.id = 1 + (random_rand() % (254 - 0 + 1));
                    LOG_INFO("New node id: %d, has the same as the leader\n", node.id);
                } 

                start_election();

                break;
            }
            break;

        case ENERGY_LOW:
            LOG_INFO("Energy low... (E:%d)\n", node.energy);
            break;

        case ENERGY_GONE:
            if (!node_dead) {
                node_dead = true;
                LOG_INFO("Node is dead writing out all the data... (E:%d)\n", node.energy);
                print_file_contents(ENERGY_FILE);
                print_file_contents(COORDINATOR_FILE);
                print_file_contents(ELECTION_FILE);
                print_file_contents(DATA_FILE);
            } 
            break;

        default:
            LOG_WARN("Unknown state: %d\n", node_state);
            break;
        }

        decrease_energy(&node);
        etimer_reset(timer_data.timer);
    }

    PROCESS_END();
}


void input_callback(const void *data, uint16_t len, const linkaddr_t *src, const linkaddr_t *dest) {
    if(len != sizeof(msg_t)) {
        LOG_WARN("Received packet of unexpected length\n");
        return;
    }

    msg_t *received_msg = (msg_t *)data;

    if (received_msg->sender_node_data.sender_id == node.id && received_msg->sender_node_data.sender_energy == node.energy) {
        LOG_DBG("Received own message. Ignoring...\n");
        return;
    }

    // Increment message count for election-related messages
    if (received_msg->type == MSG_START_ELECTION || 
        received_msg->type == MSG_OK || 
        received_msg->type == MSG_COORDINATOR) {
        local_message_count++;
    }

    switch (received_msg->type) {
        case MSG_START_COLLECTION_ELECTION_DATA:
            if (election_status == ELECTION_NONE) {
                log_election_energy_data(ELECTION_FILE, "Start");
                on_going_election++;
            }
            break;

        case MSG_START_ELECTION:
            // Check if the node's energy is below the threshold
            if (node.energy < ENERGY_THRESHOLD_LEVEL) {
                LOG_DBG("Energy below threshold.\n");
                break;
            }

            // If the sending node has a higher energy level than the other nodee
            // if (node.energy < received_msg->sender_node_data.sender_energy) {
            //     LOG_DBG("Node ID %d is less energy than sender ID %d.\n", node.id, received_msg->sender_node_data.sender_id);
            //     break;
            // }

            // If the sending node has a higher node ID but insufficient energy, abort election
            if (node.id < received_msg->sender_node_data.sender_id) {
                LOG_DBG("Node ID %d is less than sender ID %d.\n", node.id, received_msg->sender_node_data.sender_id);
                break;
            }

            LOG_INFO("Got election from %d (E:%d)\n", received_msg->sender_node_data.sender_id, received_msg->sender_node_data.sender_energy);
            msg_t start_election_msg = {
                .type = MSG_OK,
                .sender_node_data = { .sender_id = node.id, .sender_energy = node.energy }
            };
            LOG_DBG("Sending OK message\n");

            nullnet_buf = (uint8_t *)&start_election_msg;
            nullnet_len = sizeof(start_election_msg);
            LOG_INFO("Sending MSG_OK to node %d\n", received_msg->sender_node_data.sender_id);
            NETSTACK_NETWORK.output(src);

            got_election_msg = true;
            start_election(received_msg->sender_node_data.sender_id);
            break;

        case MSG_OK:
            // 4. When P receives a "Victory" message:
            //     a. Recognize the sender as the new coordinator.
            LOG_INFO("OK recived from %d \n", received_msg->sender_node_data.sender_id);
            election_status = ELECTION_NONE;
            message_status = OK;
            ctimer_stop(timer_data.e_timer);
            break;

        case MSG_HEARTBEAT:
            // 5. When P receives a heartbeat message from the coordinator:
            //     a. Update the heartbeat time.
            LOG_INFO("Heartbeat recived from %d \n", received_msg->sender_node_data.sender_id);
            timer_data.heartbeat = clock_time();
            node_type = MEMBER;
            coordinator_node.id = received_msg->sender_node_data.sender_id;
            coordinator_node.status = PRESENT;
            break;

        case MSG_COORDINATOR:
            // 6. When P receives a "Coordinator" message:
            //     a. Update the coordinator ID.
            //     b. Update the coordinator status.
            LOG_INFO("New coordinator %d \n", received_msg->sender_node_data.sender_id);
            linkaddr_copy(&coordinator_node.address, src);
            coordinator_node.id = received_msg->sender_node_data.sender_id;
            coordinator_node.status = PRESENT;
            election_status = ELECTION_NONE;
            election_coordinator_found = true;
            node_type  = MEMBER;
            timer_data.heartbeat = clock_time();
            ctimer_stop(timer_data.e_timer);

            msg_t collect_count_msg = {
                .type = MSG_MESSAGE_COUNT,
                .sender_node_data = { .sender_id = node.id, .sender_energy = node.energy },
                .message_count  = local_message_count,
            };
            LOG_DBG("Sending OK message\n");
            //print_msg(&collect_count_msg);

            nullnet_buf = (uint8_t *)&collect_count_msg;
            nullnet_len = sizeof(collect_count_msg);
            LOG_INFO("Sending message count %d\n", received_msg->sender_node_data.sender_id);
            NETSTACK_NETWORK.output(&coordinator_node.address);

            log_election_energy_data(ELECTION_FILE, "End");
            election_number++;
            local_message_count = 0; // Reset message count

            break;

        case MSG_GATHER_DATA:
            // Get Temperature and Humidity from other nodes and after a while update the overall temperature and humidity
            // We will here put the information together. However the coordinator should log this information to a file after a certain amount of time
            measurements.humidity += received_msg->measurements.humidity;
            measurements.temperature += received_msg->measurements.temperature;
            total_data_count++;

            ctimer_set(&gathering_count_reset_timer, CLOCK_SECOND * 20, report_gathering_callback, NULL);
            break;

        case MSG_MESSAGE_COUNT:
            total_message_count += received_msg->message_count;
            LOG_INFO("Received message count from node %d: %d\n", received_msg->sender_node_data.sender_id, received_msg->message_count);
            LOG_INFO("Local message count from node %d:\n", local_message_count);

            ctimer_set(&count_reset_timer, CLOCK_SECOND * 3, reset_counts_callback, NULL);
        
            // Coordinator should determine when it has received a "Count" message from all nodes, could be a timer or something else
            // After receiving then log the message of the total messages count and reset the total_message_count
            break;
        default:
            LOG_WARN("Unknown message type. Got type %d\n", received_msg->type);
            break;
    }
}

bool is_low_energy(node_t *node) {
    if (node->energy > ENERGY_THRESHOLD_LEVEL) return false;

    node_state = ENERGY_LOW;
    return true;
}

void start_election() {
    // Fast return if already in an election or insufficient energy
    LOG_DBG("Start Election status check: %s, Energy check: %s\n",
         (election_status == ELECTION_IN_PROGRESS) ? "true" : "false",
         is_low_energy(&node) ? "true" : "false");

    if (election_status == ELECTION_IN_PROGRESS ||
        is_low_energy(&node)) return;

    election_status = ELECTION_IN_PROGRESS;
    election_coordinator_found = false;
    message_status = NONE;

    // Broadcast that we would like to monitor the start election to end election for the resources
    if (!got_election_msg) {
        msg_t start_monitoring = {  .type = MSG_START_COLLECTION_ELECTION_DATA };
        nullnet_buf = (uint8_t *)&start_monitoring;
        nullnet_len = sizeof(start_monitoring);
        NETSTACK_NETWORK.output(NULL); 
        
        log_election_energy_data(ELECTION_FILE, "Start");
        on_going_election++;
    } else {
        got_election_msg = false; // Reset
    }

    msg_t start_election_msg = {
                    .type = MSG_START_ELECTION,
                    .sender_node_data = { .sender_id = node.id, .sender_energy = node.energy }
                };
    LOG_DBG("Sending start election message\n");
    

    nullnet_buf = (uint8_t *)&start_election_msg;
    nullnet_len = sizeof(start_election_msg);
    NETSTACK_NETWORK.output(NULL); // Broadcast

    ctimer_set((timer_data.e_timer), CLOCK_SECOND * 5, (void (*)(void *))handle_election_timeout, &node);
}

void handle_election_timeout(node_t *node) {
    LOG_DBG("Election status check: %s, Energy check: %s, Election in progress: %s\n",
         (message_status == OK) ? "OK" : "NONE",
         is_low_energy(node) ? "true" : "false",
         (election_status == ELECTION_NONE) ? "ELECTION_NONE" : "ELECTION_IN_PROGRESS");

    if (is_low_energy(node) ||
        election_status == ELECTION_NONE ||
        message_status == OK) return;

    election_status = ELECTION_NONE;
    node_type = COORDINATOR;
    coordinator_node.id = node->id;
    election_coordinator_found = true;

    msg_t start_election_msg = {
                    .type = MSG_COORDINATOR,
                    .sender_node_data = { .sender_id = node->id, .sender_energy = node->energy }
                };
    LOG_DBG("Sending coordinator message\n");
    //print_msg(&start_election_msg);

    LOG_INFO("[N%d] New coordinator %d (E:%d)\n", node->id, coordinator_node.id, node->energy);

    nullnet_buf = (uint8_t *)&start_election_msg;
    nullnet_len = sizeof(start_election_msg);
    NETSTACK_NETWORK.output(NULL); // Broadcast// Broadcast

    LOG_INFO("[N%d] Won election (E:%d)\n", node->id, node->energy);
    log_election_energy_data(ELECTION_FILE, "End");
    election_number++;
}


void handle_node_state_change(coordinator_node_t* node){

    switch (node->status)
    {
    case ABSENT:
        node_type = ORPHAN;
        break;
    case PRESENT:
        node_type = MEMBER;
        break;
    }
}

void decrease_energy(node_t *node) {
    if (node->energy <= ENERGY_LOSS) {
        node_state = ENERGY_GONE;
        // Prevent underflow
        return;
    }

    node->energy -= ENERGY_LOSS;
}

void log_scaled_value(const char *label, float scaled_value, const char *unit){
    // Multiply by 100 to shift two decimal places
    int scaled_value_int = (int)(scaled_value * 100);

    // Print the label, integer part, and fractional part
    LOG_DBG("%s: %d.%02d%s\n",
           label,
           scaled_value_int / 100,     // Integer part
           scaled_value_int % 100,     // Fractional part
           unit);                      // Unit (e.g., "%", "°C")
}

bool has_timeout_occurred(clock_time_t last_heartbeat, uint16_t timeout_seconds) {
    // Calculate the timeout duration in clock ticks
    clock_time_t timeout_ticks = timeout_seconds * CLOCK_SECOND;

    // Get the current time
    clock_time_t current_time = clock_time();

    // Check if the current time exceeds the last heartbeat + timeout duration
    bool result = (current_time - last_heartbeat) > timeout_ticks;

    // Log statement
    LOG_DBG("Checking timeout: current_time=%lu, last_heartbeat=%lu, timeout_seconds=%u, timeout_ticks=%lu, result=%s\n",
           (unsigned long)current_time,
           (unsigned long)last_heartbeat,
           (unsigned int)timeout_seconds,
           (unsigned long)timeout_ticks,
           result ? "true" : "false");

    return result;
}

// Convert raw values to human-readable format (example conversion)
float convertToCelsius(float temperature){
  return ((temperature / 10) - 396) / 10;
}

float convertToHumidity(float humidity){
   // Constants for 12-bit resolution humidity calculation
  const float c1 = -2.0468;
  const float c2 = 0.0367;
  const float c3 = -1.5955e-6;

  // Calculate linear relative humidity using the formula
  float RH_linear = c1 + (c2 * humidity) + (c3 * humidity * humidity); // pow(humidity, 2)

  // Clamp RH to a maximum of 100% if it exceeds physical limits
  if (RH_linear > 100) {
    RH_linear = 100;
  }

  return RH_linear;
}

void log_energy_data(const char *filename) {
    energest_flush();
    uint64_t cpu_new = to_seconds(energest_type_time(ENERGEST_TYPE_CPU));
    uint64_t lpm_new = to_seconds(energest_type_time(ENERGEST_TYPE_LPM));
    uint64_t transmit_new = to_seconds(energest_type_time(ENERGEST_TYPE_TRANSMIT));
    uint64_t listen_new = to_seconds(energest_type_time(ENERGEST_TYPE_LISTEN));
    LOG_DBG("CPU: %" PRIu64 ", LPM: %" PRIu64 ", Transmit: %" PRIu64 ", Listen: %" PRIu64 "\n",
         cpu_new, lpm_new, transmit_new, listen_new);

    int fd = cfs_open(filename, CFS_WRITE | CFS_APPEND);

    char buf[250];

    if(fd >= 0) {
        //int len = snprintf(buf, sizeof(buf), "CPU: %"PRIu64", LPM: %"PRIu64", Transmit: %"PRIu64", Listen: %"PRIu64" \n", cpu_new, lpm_new, transmit_new, listen_new);
        int len = snprintf(buf, sizeof(buf), "CPU: %"PRIu64", LPM: %"PRIu64", Transmit: %"PRIu64", Listen: %"PRIu64" \n", cpu_new, lpm_new, transmit_new, listen_new);

        if (len < 0 || len >= sizeof(buf)) {
            LOG_WARN("Error: Buffer overflow or snprintf failed\n");
        } else {
            if(cfs_write(fd, buf, len) < 0) {
                LOG_WARN("Failed to write data to file\n");
            } else {
                LOG_DBG("Energy data written to file.\n");
            }
        }

        cfs_close(fd);
    } else {
        LOG_WARN("Failed to open file for writing.\n");
    }
}

void log_election_energy_data(const char *filename, const char *state) {
    if (election_number == on_going_election) {
        return;
    }

    energest_flush();
    uint64_t cpu = energest_type_time(ENERGEST_TYPE_CPU);
    uint64_t lpm = energest_type_time(ENERGEST_TYPE_LPM);
    uint64_t transmit = energest_type_time(ENERGEST_TYPE_TRANSMIT);
    uint64_t listen = energest_type_time(ENERGEST_TYPE_LISTEN);

    LOG_DBG("Writing to file: %" PRIu8 " - %s: CPU: %" PRIu64 ", LPM: %" PRIu64 ", Transmit: %" PRIu64 ", Listen: %" PRIu64 "\n", 
        election_number, state, cpu, lpm, transmit, listen);

    int fd = cfs_open(filename, CFS_WRITE | CFS_APPEND);

    char buf[250];

    if(fd >= 0) {
        int len = snprintf(buf, sizeof(buf), 
            "%" PRIu8 " - %s: CPU: %" PRIu64 ", LPM: %" PRIu64 ", Transmit: %" PRIu64 ", Listen: %" PRIu64 "\n", 
            election_number, state, cpu, lpm, transmit, listen);

        if (len < 0 || len >= sizeof(buf)) {
            LOG_WARN("Error: Buffer overflow or snprintf failed\n");
        } else {
            if(cfs_write(fd, buf, len) < 0) {
                LOG_WARN("Failed to write data to file\n");
            } else {
                LOG_DBG("Energy data written to file.\n");
            }
        }

        cfs_close(fd);
    } else {
        LOG_WARN("Failed to open file for writing.\n");
    }
}

void print_file_contents(const char *filename) {
    char buf[200];
    int fd = cfs_open(filename, CFS_READ);
    LOG_INFO("Reading file: %s\n", filename);

    if (fd >= 0) {
        int bytes_read;
        while ((bytes_read = cfs_read(fd, buf, sizeof(buf) - 1)) > 0) {
            buf[bytes_read] = '\0'; // Null-terminate
            LOG_DBG("%s", buf);      // Print to serial
        }
        cfs_close(fd);
    } else {
        LOG_WARN("Failed to open file for reading.\n");
    }
}

void log_gathering_data(float temperature, float humidity) {
    int fd = cfs_open(DATA_FILE, CFS_WRITE | CFS_APPEND);
    char buf[100];

    if(fd >= 0) {
        log_gathering_data_count++;

        int temp_scaled = (int)(temperature * 100);
        int hum_scaled = (int)(humidity * 100);

        int len = snprintf(buf, sizeof(buf),
                           "%d: Temperature %d.%02d, Humidity %d.%02d\n",
                           log_gathering_data_count,
                           temp_scaled / 100, temp_scaled % 100,
                           hum_scaled / 100, hum_scaled % 100);

        if (len < 0 || len >= sizeof(buf)) {
            LOG_WARN("Error: Buffer overflow or snprintf failed\n");
        } else {
            if(cfs_write(fd, buf, len) < 0) {
                LOG_WARN("Failed to write data to file\n");
            } else {
                LOG_DBG("Weather data written to file.\n");
            }
        }

        cfs_close(fd);
    } else {
        LOG_WARN("Failed to open file for writing.\n");
    }
}

void print_msg(const msg_t *msg) {
    LOG_DBG("Message Type: %d\n", msg->type);
    LOG_DBG("Sender ID: %u\n", msg->sender_node_data.sender_id);
    LOG_DBG("Sender Energy: %u\n", msg->sender_node_data.sender_energy);
    print_scaled_value("Temperature", msg->measurements.temperature, "°C");
    print_scaled_value("Humidity", msg->measurements.humidity, "%");
}

void print_scaled_value(const char *label, float scaled_value, const char *unit) {
    // Multiply by 100 to shift two decimal places
    int scaled_value_int = (int)(scaled_value * 100);

    // Print the label, integer part, and fractional part
    LOG_DBG("%s: %d.%02d%s\n",
           label,
           scaled_value_int / 100,     // Integer part
           scaled_value_int % 100,     // Fractional part
           unit);                      // Unit (e.g., "%", "°C")
}

void reset_counts_callback(void *ptr) {

    total_message_count += local_message_count;
    LOG_INFO("Election %"PRIu16"  had a total of %d succesfull recieved messages\n", election_number, total_message_count);
    //LOG_WARN("Timeout reached before receiving all message counts. Resetting counters.\n");
    total_message_count = 0;
    local_message_count = 0;
}

void report_gathering_callback(void *ptr) {
    if (node_type == COORDINATOR) {
        //LOG_WARN("Timeout reached before receiving all message counts. Resetting counters.\n");
        float temperature = measurements.temperature / total_data_count;
        float humidity =  measurements.humidity / total_data_count;

        LOG_DBG("Recieved total count of %d data\n", total_data_count);
        log_scaled_value("Temperature", temperature, "°C");
        log_scaled_value("Humidity", humidity, "%");

        log_gathering_data(temperature, humidity);
        total_data_count = 0;
    }
}

static unsigned long to_seconds(uint64_t time) {
    return (unsigned long)(time / ENERGEST_SECOND);
}