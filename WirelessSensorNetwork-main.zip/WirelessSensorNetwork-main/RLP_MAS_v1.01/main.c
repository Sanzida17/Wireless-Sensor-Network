#include "contiki.h"
#include "net/ip/simple-udp.h"
#include "net/rpl/rpl.h"
#include "sys/node-id.h"
#include <stdio.h>

#define UDP_PORT 8765
#define MSG_ELECTION 1
#define MSG_OK 2
#define MSG_COORD 3
#define MSG_HEART 4

#define MIN_ENERGY 20  // Minimum energy to participate
#define ENERGY_LOSS 1  // Energy loss per interval
#define START_ENERGY 100 // Starting energy

typedef struct {
    uint8_t type;
    uint16_t id;
    uint8_t energy;
} msg_t;

static struct simple_udp_connection conn;
static uint16_t coord = 0;
static uint8_t election = 0;
static struct etimer timer;
static struct ctimer e_timer;
static clock_time_t last = 0;
static uint8_t received_ok = 0;
static uint8_t energy = START_ENERGY;

// Function declarations
static void send(uint16_t to, uint8_t type);
static void broadcast(uint8_t type, uint16_t start, uint16_t end);
static void start_election(void);
static void handle_election_timeout(void *ptr);

static void print_status(void) {
    printf("[N%d] E:%d %s\n", node_id, energy, 
           coord == node_id ? "COORD" : 
           coord > 0 ? "MEMBER" : "ORPHAN");
}

static void send(uint16_t to, uint8_t type) {
    msg_t msg = {type, node_id, energy};
    uip_ipaddr_t addr;
    uip_ip6addr(&addr, 0xaaaa, 0, 0, 0, 0, 0, 0, to);
    simple_udp_sendto(&conn, &msg, sizeof(msg), &addr);
}

static void broadcast(uint8_t type, uint16_t start, uint16_t end) {
    uint16_t i;
    for(i = start; i <= end; i++) {
        if(i != node_id) send(i, type);
    }
}

static void handle_election_timeout(void *ptr) {
    if(election && !received_ok && energy > MIN_ENERGY) {
        election = 0;
        coord = node_id;
        broadcast(MSG_COORD, 1, node_id - 1);
        printf("[N%d] Won election (E:%d)\n", node_id, energy);
        print_status();
    }
}

static void start_election(void) {
    if(!election && energy > MIN_ENERGY) {
        election = 1;
        received_ok = 0;
        printf("[N%d] Starting election (E:%d)\n", node_id, energy);
        broadcast(MSG_ELECTION, node_id + 1, 255);
        ctimer_set(&e_timer, CLOCK_SECOND * 5, handle_election_timeout, NULL);
    }
}

static void rx(struct simple_udp_connection *c,
              const uip_ipaddr_t *sender,
              uint16_t port,
              const uip_ipaddr_t *receiver,
              uint16_t recv_port,
              const uint8_t *data,
              uint16_t len) {
    if(len != sizeof(msg_t)) return;
    msg_t *msg = (msg_t *)data;
    
    switch(msg->type) {
        case MSG_ELECTION:
            if(msg->id < node_id && energy > MIN_ENERGY) {
                printf("[N%d] Got election from N%d (E:%d)\n", node_id, msg->id, msg->energy);
                send(msg->id, MSG_OK);
                start_election();
            }
            break;
            
        case MSG_OK:
            if(election && msg->id > node_id) {
                printf("[N%d] Got OK from N%d (E:%d)\n", node_id, msg->id, msg->energy);
                received_ok = 1;
                election = 0;
                ctimer_stop(&e_timer);
            }
            break;
            
        case MSG_COORD:
            if(msg->id > coord) {
                coord = msg->id;
                last = clock_time();
                election = 0;
                ctimer_stop(&e_timer);
                printf("[N%d] New coord N%d (E:%d)\n", node_id, coord, msg->energy);
                print_status();
            }
            break;
            
        case MSG_HEART:
            if(msg->id == coord) {
                last = clock_time();
                if(coord != node_id) {
                    printf("[N%d] Heartbeat from N%d (E:%d)\n", node_id, coord, msg->energy);
                }
            }
            break;
    }
}

PROCESS(bully_process, "Bully");
AUTOSTART_PROCESSES(&bully_process);

PROCESS_THREAD(bully_process, ev, data) {
    PROCESS_BEGIN();
    
    // Setup RPL for node 1
    if(node_id == 1) {
        uip_ipaddr_t ipaddr;
        uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 1);
        uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);
        rpl_dag_t *dag = rpl_set_root(RPL_DEFAULT_INSTANCE, &ipaddr);
        if(dag) {
            uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
            rpl_set_prefix(dag, &ipaddr, 64);
        }
        coord = 1;
        printf("[N1] Starting as coordinator (E:%d)\n", energy);
    }
    
    simple_udp_register(&conn, UDP_PORT, NULL, UDP_PORT, rx);
    
    // Wait for network to stabilize
    etimer_set(&timer, CLOCK_SECOND * (5 + (node_id % 5)));
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&timer));
    
    print_status();
    etimer_set(&timer, CLOCK_SECOND * 10);
    
    while(1) {
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&timer));
        
        // Decrease energy
        if(energy >= ENERGY_LOSS) {
            energy -= ENERGY_LOSS;
            if((energy % 10) == 0) {
                print_status();
            }
        }
        
        // Step down if energy too low
        if(coord == node_id && energy < MIN_ENERGY) {
            printf("[N%d] Stepping down: low energy (%d)\n", node_id, energy);
            coord = 0;
            broadcast(MSG_ELECTION, node_id + 1, 255);
        }
        
        // Regular coordinator actions
        if(coord == node_id && energy > MIN_ENERGY) {
            broadcast(MSG_HEART, 1, node_id - 1);
        } else if(!election && (coord == 0 || clock_time() - last > CLOCK_SECOND * 30)) {
            start_election();
        }
        
        etimer_reset(&timer);
    }
    
    PROCESS_END();
}