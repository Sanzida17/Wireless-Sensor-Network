#include <stdio.h>

#include "inc/bully.h"
#include "inc/election.h"
#include "inc/energy.h"
#include "inc/logs.h"
#include "inc/messages.h"
#include "inc/network_msg.h"
#include "inc/node_management.h"
#include "inc/status_strings.h"
#include "inc/sensors_helper.h"
#include "inc/timer_helper.h"
#include "inc/types.h"
#include "lib/random.h"

PROCESS(bully_process, "Bully");
AUTOSTART_PROCESSES(&bully_process);

election_data_t election_data;
timer_data_t timer_data;
measurements_t measurements;

static struct etimer timer;
static struct ctimer e_timer;

static struct simple_udp_connection udp_server_conn;
static struct simple_udp_connection udp_client_conn;
static uip_ipaddr_t dest_ipaddr;
static uint32_t rx_count = 0;
static uint32_t tx_count = 0;
static uint32_t missed_tx_count = 0;



// void handle_network_communication(uint32_t *tx_count, uint32_t *rx_count, uint32_t *missed_tx_count, 
//                                   struct simple_udp_connection *udp_conn, char *str, 
//                                   size_t str_size, uip_ipaddr_t *dest_ipaddr) {
//     if(NETSTACK_ROUTING.node_is_reachable() &&
//        NETSTACK_ROUTING.get_root_ipaddr(dest_ipaddr)) {

//         /* Print statistics every 10th TX */
//         if(*tx_count % 10 == 0) {
//             LOG_INFO("Tx/Rx/MissedTx: %" PRIu32 "/%" PRIu32 "/%" PRIu32 "\n",
//                      *tx_count, *rx_count, *missed_tx_count);
//         }

//         /* Send to DAG root */
//         LOG_INFO("Sending request %"PRIu32" to ", *tx_count);
//         LOG_INFO_6ADDR(dest_ipaddr);
//         LOG_INFO_("\n");
//         snprintf(str, str_size, "hello %" PRIu32 "", *tx_count);
//         simple_udp_sendto(udp_conn, str, strlen(str), dest_ipaddr);
//         (*tx_count)++;
//     } else {
//         LOG_INFO("Not reachable yet\n");
//         if(*tx_count > 0) {
//             (*missed_tx_count)++;
//         }
//     }
// }
// uint8_t num_nodes = /* Initialize with the number of nodes */;
// uint8_t active_nodes[MAX_NODES] = { /* Initialize with active node IDs */ };
static void
udp_server_rx_callback(struct simple_udp_connection *c,
                      const uip_ipaddr_t *sender_addr,
                      uint16_t sender_port,
                      const uip_ipaddr_t *receiver_addr,
                      uint16_t receiver_port,
                      const uint8_t *data,
                      uint16_t datalen)
{
  LOG_INFO("Server received request '%.*s' from ", datalen, (char *) data);
  LOG_INFO_6ADDR(sender_addr);
  LOG_INFO_("\n");
#if WITH_SERVER_REPLY
  /* Echo the received data back to the client */
  LOG_INFO("Server sending response.\n");
  simple_udp_sendto(c, data, datalen, sender_addr);
#endif /* WITH_SERVER_REPLY */
}
/*---------------------------------------------------------------------------*/
static void
udp_client_rx_callback(struct simple_udp_connection *c,
                      const uip_ipaddr_t *sender_addr,
                      uint16_t sender_port,
                      const uip_ipaddr_t *receiver_addr,
                      uint16_t receiver_port,
                      const uint8_t *data,
                      uint16_t datalen)
{
  LOG_INFO("Client received response '%.*s' from ", datalen, (char *) data);
  LOG_INFO_6ADDR(sender_addr);
#if LLSEC802154_CONF_ENABLED
  LOG_INFO_(" LLSEC LV:%d", uipbuf_get_attr(UIPBUF_ATTR_LLSEC_LEVEL));
#endif
  LOG_INFO_("\n");
  rx_count++;
}

PROCESS_THREAD(bully_process, ev, data) {
    PROCESS_BEGIN();
    static char str[32];
    // uip_ipaddr_t dest_ipaddr;
    // static uint32_t tx_count;
    //static uint32_t missed_tx_count;

    random_init((unsigned short)node_id);
    election_data.node.id = node_id; // Assign appropriate node_id
    election_data.coordinator.id = 0; 
    election_data.coordinator.status = ABSENT;
    election_data.node.energy = MIN_RANDOM + (random_rand() % (MAX_RANDOM - MIN_RANDOM + 1));;
    election_data.type = ORPHAN;
    election_data.election = ELECTION_NONE;
    election_data.received = RECEIVED_NO;
    election_data.currentState = INIT_NODE_TYPE;

    timer_data.timer = &timer;
    timer_data.e_timer = &e_timer;
    timer_data.heartbeat = clock_time();
    SENSORS_ACTIVATE(sht11_sensor);
    
    while(1) {
        switch (election_data.currentState)
        {
        case INIT_NODE_TYPE:
            //LOG_INFO("[N%d] STATE Deciding Node Type... (E:%d)\n", election_data.node.id, election_data.node.energy);
            decide_node_type(&election_data, &timer_data);
            break;    

        case STATE_MEMBER_NODE_START_LISTING:
            //LOG_INFO("[N%d] STATE Start Node Listen... (E:%d)\n", election_data.node.id, election_data.node.energy);
            simple_udp_register(&udp_client_conn, UDP_CLIENT_PORT, NULL, UDP_SERVER_PORT, udp_client_rx_callback);
    
            etimer_set(timer_data.timer, CLOCK_SECOND * (5 + (election_data.node.id % 5)));
            election_data.currentState = STATE_MEMBER_IDLE;
            break;
        
        case STATE_COORDINATOR_INITIAL_SETUP:
            //LOG_INFO("[N%d] STATE Coordinator Initialises... (E:%d)\n", election_data.node.id, election_data.node.energy);
            NETSTACK_ROUTING.root_start();
            simple_udp_register(&udp_server_conn, UDP_SERVER_PORT, NULL, UDP_CLIENT_PORT, udp_server_rx_callback);
    
            //setupCooridnator(&election_data, &timer_data);
            set_coordinator(&election_data);
            //start_client_listening(&udp_conn, &election_data.node, timer_data.timer);
            uip_ip6addr(&dest_ipaddr, 0xfd00,0,0,0x212,0x7401,0x1,0x101,0x1); // why???
            break;

        case STATE_COORDINATOR_SET_NEW_NODE:
            // How to set new coordinator?
            break;

        case STATE_COORDINATOR_ACTION:
            //LOG_INFO("[N%d] STATE Coordination Action... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_low_energy(&election_data))
                step_down_as_coordinator(&election_data);
            //handle_network_communication(&tx_count, &rx_count, &missed_tx_count, &udp_conn, str, sizeof(str), &dest_ipaddr);

            break;

        case STATE_MEMBER_IDLE:
            //LOG_INFO("[N%d] STATE Member... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_orphan(&election_data))
                break;

            // READ DATA FROM SENSORS
            readSensors(&measurements);
            // SEND DATA 
            measurements.temperature = convertToCelsius(measurements.temperature);
            measurements.humidity = convertToHumidity(measurements.humidity);
            log_scaled_value("Temperature", measurements.temperature, "°C");
            log_scaled_value("Humidity", measurements.humidity, "%");
            

            broadcast(MSG_HEART, 1, election_data.node.id - 1, &election_data.node);
            break;

        case STATE_ORPHAN_IDLE:
            //LOG_INFO("[N%d] STATE Orphan... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_member(&election_data))
                should_start_election(&election_data, &timer_data);
            
            if(NETSTACK_ROUTING.node_is_reachable() &&
               NETSTACK_ROUTING.get_root_ipaddr(&dest_ipaddr)) {

                /* Print statistics every 10th TX */
                if(tx_count % 10 == 0) {
                    LOG_INFO("Tx/Rx/MissedTx: %" PRIu32 "/%" PRIu32 "/%" PRIu32 "\n",
                             tx_count, rx_count, missed_tx_count);
                }

                /* Send to DAG root */
                LOG_INFO("Sending request %"PRIu32" to ", tx_count);
                LOG_INFO_6ADDR(&dest_ipaddr);
                LOG_INFO_("\n");
                snprintf(str, sizeof(str), "hello %" PRIu32 "", tx_count);
                simple_udp_sendto(&udp_client_conn, str, strlen(str), &dest_ipaddr);
                tx_count++;
            } else {
                LOG_INFO("Not reachable yet\n");
                if(tx_count > 0) {
                    missed_tx_count++;
                }
            }
            //broadcast(MSG_HEART, 1, election_data.node.id - 1, &election_data.node);
            break;

        case STATE_NODE_START_ELECTION:
            //LOG_INFO("[N%d] STATE Election: Starting election... (E:%d)\n", election_data.node.id, election_data.node.energy);
            start_election(&election_data, &timer_data);
            break;

        case ENERGY_LOW:
            //LOG_INFO("[N%d] STATE Energy Low... (E:%d)\n", election_data.node.id, election_data.node.energy);

            break;
        case ENERGY_GONE:
            //LOG_INFO("[N%d] STATE Energy Gone...\n", election_data.node.id);
            break;

        default:
            //LOG_WARN("[N%d] Unknown state: %d\n", election_data.node.id, election_data.currentState);
            break;
        }

        decrease_energy(&election_data);
        //log_metadata(&election_data);   
     
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(timer_data.timer));
        //etimer_reset(timer_data.timer);
        // Reset the main event timer if expired
        etimer_reset(timer_data.timer);
    }
    
    PROCESS_END();
}

