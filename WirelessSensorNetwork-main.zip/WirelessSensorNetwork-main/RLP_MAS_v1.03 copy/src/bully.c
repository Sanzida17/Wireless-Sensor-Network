#include "inc/bully.h"

bool is_sender_stronger_than_current_node(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id) < election_data->node.id;
}

bool is_sender_weaker_than_current_node(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id) > election_data->node.id;
}

bool is_sender_weaker_than_coordinator_node(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id) <= election_data->coordinator.id;
}

bool is_sender_coordinator(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id == election_data->coordinator.id);
}

void set_coordinator(election_data_t *election_data){
    election_data->coordinator.id = election_data->node.id;
    election_data->coordinator.status = PRESENT;
    election_data->currentState = STATE_COORDINATOR_ACTION;
}

void reset_coordinator_to_member(election_data_t *election_data) {
    // Remove the election_data->coordinator = 0
    election_data->coordinator.id = election_data->node.id;
    election_data->coordinator.status = ABSENT;
    election_data->currentState = STATE_ORPHAN_IDLE;
}
