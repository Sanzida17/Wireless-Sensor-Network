#include "inc/energy.h"

bool is_low_energy(election_data_t *election_data) {
    if (election_data->node.energy > ENERGY_THRESHOLD_LEVEL) return false;

    election_data->currentState = ENERGY_LOW;
    return true;
}

bool has_sufficient_energy(election_data_t *election_data) {
    if (election_data->node.energy > ENERGY_THRESHOLD_LEVEL) return true;

    election_data->currentState = ENERGY_LOW;

    return false;
}

void decrease_energy(election_data_t *election_data) {
    if (election_data->node.energy <= ENERGY_LOSS) {
        election_data->currentState = ENERGY_GONE;
        // Prevent underflow
        return;
    }

    election_data->node.energy -= ENERGY_LOSS;
}