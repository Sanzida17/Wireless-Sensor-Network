#include "inc/sensors_helper.h"

void readSensors(measurements_t *measurements) {
  // Read temperature and humidity from the SHT11 sensor
  measurements->temperature = sht11_sensor.value(SHT11_SENSOR_TEMP);
  measurements->humidity = sht11_sensor.value(SHT11_SENSOR_HUMIDITY);
}

// Convert raw values to human-readable format (example conversion)
float convertToCelsius(float temperature){
  return ((temperature / 10) - 396) / 10;
}

float convertToHumidity(float humidity){
   // Constants for 12-bit resolution humidity calculation
  const float c1 = -2.0468;
  const float c2 = 0.0367;
  const float c3 = -1.5955e-6;

  // Calculate linear relative humidity using the formula
  float RH_linear = c1 + (c2 * humidity) + (c3 * humidity * humidity); // pow(humidity, 2)

  // Clamp RH to a maximum of 100% if it exceeds physical limits
  if (RH_linear > 100) {
    RH_linear = 100;
  }

  return RH_linear;
}


