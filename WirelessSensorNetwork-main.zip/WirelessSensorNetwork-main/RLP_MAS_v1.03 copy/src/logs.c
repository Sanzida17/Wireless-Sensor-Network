#include "inc/logs.h"

// void log_metadata(election_data_t *election_data) {
//     if ((election_data->node.energy % 10) != 0) return;
//     if (election_data->node.energy == 0) return;

//     LOG_INFO("[N%d] E:%d %s\n", election_data->node.id, election_data->node.energy,
//            election_data->type == STATE_COORDINATOR ? STATUS_COORDINATOR : 
//              election_data->coordinator.status == PRESENT ? STATUS_MEMBER : STATUS_ORPHAN);
// }

// Function to print a scaled value as a floating-point number with two decimal places
void log_scaled_value(const char *label, float scaled_value, const char *unit) {
    // Multiply by 100 to shift two decimal places
    int scaled_value_int = (int)(scaled_value * 100);

    // Print the label, integer part, and fractional part
    LOG_INFO("%s: %d.%02d%s\n", 
           label,
           scaled_value_int / 100,     // Integer part
           scaled_value_int % 100,     // Fractional part
           unit);                      // Unit (e.g., "%", "°C")
}

void log_step_down(const election_data_t *election_data) {
    LOG_INFO("[N%d] Stepping down: low energy (%d)\n", election_data->node.id, election_data->node.energy);
}