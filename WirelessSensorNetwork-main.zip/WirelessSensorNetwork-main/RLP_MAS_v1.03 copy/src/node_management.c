#include "inc/node_management.h"


// void decrease_and_log_energy(election_data_t *election_data){
//     if (decrease_energy(election_data)) return;
    
//     log_metadata(election_data);   
// }

void start_client_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer){
    //simple_udp_register(conn, UDP_PORT, NULL, UDP_PORT, rx_callback); // WHY ON THE SAME PORT?
    simple_udp_register(conn, UDP_CLIENT_PORT, NULL,
                      UDP_SERVER_PORT, rx_callback);
    
    etimer_set(timer, CLOCK_SECOND * (5 + (node->id % 5)));

    return;
}

void start_server_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer){
    //simple_udp_register(conn, UDP_PORT, NULL, UDP_PORT, rx_callback); // WHY ON THE SAME PORT?
    simple_udp_register(conn, UDP_SERVER_PORT, NULL,
                      UDP_CLIENT_PORT, rx_callback);
    
    etimer_set(timer, CLOCK_SECOND * (5 + (node->id % 5)));

    return;
}

void setupCooridnator(election_data_t *election_data, timer_data_t *timer_data){
    // Setup RPL for node 1
    
    //election_data.node.id = id;
    // uip_ipaddr_t ipaddr;
    // uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 1);
    // uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);
    
    // rpl_dag_init_root(RPL_DEFAULT_INSTANCE, &ipaddr, &ipaddr, 64, 0);
    NETSTACK_ROUTING.root_start();
    return;
}

// Function to handle regular coordinator actions and trigger elections if needed
void step_down_as_coordinator(election_data_t *election_data) {
    LOG_INFO("[N%d] Stepping down: low energy (%d)\n", election_data->node.id, election_data->node.energy);
    reset_coordinator_to_member(election_data);
    broadcast(MSG_ELECTION, election_data->node.id + 1, 255, &election_data->node);
}

bool is_orphan(election_data_t *election_data) {
    LOG_DBG("Checking if node is orphan: coordinator.stats=%d\n", election_data->coordinator.status);

    if (election_data->coordinator.status == PRESENT) return false;

    LOG_DBG("Node is orphan. Transitioning to STATE_ORPHAN_IDLE.\n");
    election_data->currentState = STATE_ORPHAN_IDLE;
    election_data->type = ORPHAN;
    return true;
}

bool is_member(election_data_t *election_data) {
    LOG_DBG("Checking if node is member: coordinator.status=%d\n", election_data->coordinator.status);

    if (election_data->coordinator.status == ABSENT) return false;

    LOG_DBG("Node is member. Transitioning to STATE_MEMBER_IDLE.\n");
    election_data->currentState = STATE_MEMBER_IDLE;
    election_data->type = MEMBER;
    return false;
}


void should_start_election(election_data_t *election_data, const timer_data_t *timer_data) {
    // Return early if an election is already in progress
    if (election_data->election == ELECTION_IN_PROGRESS) return;

    // Return early if the heartbeat has not timed out
    if (!has_timeout_occurred(timer_data->heartbeat, 30)) return;
    
    election_data->currentState = STATE_NODE_START_ELECTION;
}

void decide_node_type(election_data_t* election_data, timer_data_t *timer_data){

    uint8_t leader = 1;

    if (election_data->node.id == leader) {
        election_data->currentState = STATE_COORDINATOR_INITIAL_SETUP;
    } else {
        election_data->currentState = STATE_MEMBER_NODE_START_LISTING;
    }
    etimer_set(timer_data->timer, CLOCK_SECOND * 10);
    // switch (election_data->node.id)
    // {
    //     case LEADER: // Now LEADER is a compile-time constant
    //         election_data->currentState = STATE_COORDINATOR;
    //         break;

    //     default:
    //         election_data->currentState = STATE_START_LISTING;
    //         break;
    // }
}

// void node_actions(election_data_t *election){
//     // Each node should perform the following actions:
//     // if(election_data.coordinator == election_data.node.id) {
//     //             election_data.currentState = STATE_COORDINATOR_OPERATING;
//     //         } else {
//     //             election_data.currentState = STATE_IDLE;
//     //         }
//     // New implemtation should do the same
//     switch (election.type) 
//     {
//     case STATE_COORDINATOR:
//         election.currentState = STATE_COORDINATOR_OPERATING;
//         break;
//     case STATE_MEMBER:
//         election.currentState = STATE_IDLE;
//         break;
//     case STATE_ORPHAN:
//         election.currentState = START_ELECTION;
//         break;
//     default:
//         break;
//     }
// }




