#include "inc/timer_helper.h"

bool has_timeout_occurred(clock_time_t last_heartbeat, uint16_t timeout_seconds) {
    // Calculate the timeout duration in clock ticks
    clock_time_t timeout_ticks = timeout_seconds * CLOCK_SECOND;

    // Check if the current time exceeds the last heartbeat + timeout duration
    return (clock_time() - last_heartbeat) > timeout_ticks;
}

void update_heartbeat(timer_data_t* timer) {
    timer->heartbeat = clock_time();  
}