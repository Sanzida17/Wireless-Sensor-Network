#ifndef MESSAGES_H
#define MESSAGES_H
#include <stdio.h>
#include <stdint.h>
#include "sys/ctimer.h" 
#include "inc/network_msg.h"
#include "inc/types.h"
#include "inc/election.h"
#include "inc/bully.h"
#include "inc/energy.h"
#include "inc/timer_helper.h"

void handle_msg_election(msg_t *msg, election_data_t *election_data, timer_data_t *timer) ;
void handle_msg_ok(msg_t *msg, election_data_t *election);
void handle_msg_coordinator(msg_t *msg, election_data_t *election_data, timer_data_t *timer);        
void handle_msg_heart(msg_t *msg, election_data_t *election, timer_data_t *timer);                   

#endif /* MESSAGES_H */
