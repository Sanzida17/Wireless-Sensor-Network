#ifndef SENSOR_H
#define SENSOR_H
#include <stdio.h>
#include "sht11-sensor.h"
#include "inc/types.h"

void readSensors(measurements_t *measurements);
float convertToCelsius(float temperature);
float convertToHumidity(float humidity);

#endif /* SENSOR_H */