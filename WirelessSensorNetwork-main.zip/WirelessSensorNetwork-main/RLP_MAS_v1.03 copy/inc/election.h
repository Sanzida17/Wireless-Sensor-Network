#ifndef ELECTION_H
#define ELECTION_H

#include <stdio.h>
#include <stdint.h>
#include "sys/ctimer.h" 
#include "inc/types.h"
#include "inc/logs.h"
#include "inc/network_msg.h"
#include "inc/energy.h"


void start_election(election_data_t *election_data, timer_data_t *timer);

void handle_election_timeout(election_data_t *election_data);

bool is_election_inprogress(const election_data_t *election_data);

bool has_not_received_ack(const election_data_t *election_data);

void election_state(election_data_t *election_data);

void election_reviced_ack(election_data_t *election_data);

#endif /* ELECTION_H */