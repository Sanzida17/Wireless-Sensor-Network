#ifndef NETWORK_MSG_H
#define NETWORK_MSG_H
#include <stdio.h>

#include "net/ipv6/simple-udp.h"
#include "contiki.h"
#include "inc/types.h"
#include "inc/messages.h"



//extern struct simple_udp_connection conn;

void send(uint16_t to, msg_t *msg);
void broadcast(MSG type, uint16_t start, uint16_t end, node_t *node);
void rx_callback(struct simple_udp_connection *c,
                 const uip_ipaddr_t *sender,
                 uint16_t port,
                 const uip_ipaddr_t *receiver,
                 uint16_t recv_port,
                 const uint8_t *data,
                 uint16_t len);

#endif /* NETWORK_H */