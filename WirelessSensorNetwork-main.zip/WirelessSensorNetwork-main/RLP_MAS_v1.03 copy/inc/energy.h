#ifndef ENERGY_H
#define ENERGY_H

#include "inc/types.h"

bool is_low_energy(election_data_t *election_data); 
bool has_sufficient_energy(election_data_t *election_data);
void decrease_energy(election_data_t *election_data);

#endif /* ENERGY_H */