#ifndef BULLY_H
#define BULLY_H

#include "inc/types.h"

bool is_sender_stronger_than_current_node(const election_data_t *election_data, msg_t *msg); 

bool is_sender_weaker_than_current_node(const election_data_t *election_data, msg_t *msg);

bool is_sender_weaker_than_coordinator_node(const election_data_t *election_data, msg_t *msg);

bool is_sender_coordinator(const election_data_t *election_data, msg_t *msg);

void set_coordinator(election_data_t *election_data);

void reset_coordinator_to_member(election_data_t *election_data);

#endif /* BULLY_H */