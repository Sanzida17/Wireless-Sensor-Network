#ifndef LOGS_H
#define LOGS_H
#include <stdio.h>
#include <stdint.h>
#include "inc/types.h"
#include "inc/status_strings.h"

//void log_metadata(election_data_t *data);
void log_scaled_value(const char *label, float scaled_value, const char *unit);
void log_step_down(const election_data_t *election_data);
#endif /* LOGS_H */