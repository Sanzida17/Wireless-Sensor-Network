#ifndef TIMER_HELPER_H
#define TIMER_HELPER_H

#include <stdint.h>
#include "sys/ctimer.h" 
#include "inc/types.h"

bool has_timeout_occurred(clock_time_t last_heartbeat, uint16_t timout_seconds);

void update_heartbeat(timer_data_t* timer);

#endif /* TIMER_HELPER_H */