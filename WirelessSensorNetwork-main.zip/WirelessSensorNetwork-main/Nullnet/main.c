#include "net/nullnet/nullnet.h"
#include "net/netstack.h"
#include "contiki.h"
#include <string.h>
#include <stdio.h>
// // Disable IPv6 and routing
// #define UIP_CONF_IPV6 0
// #define UIP_CONF_ROUTER 0

// // Disable sicslowpan
// #define NETSTACK_CONF_NETWORK nullnet_driver
static uint8_t payload[] = "Hello, NullNet!";

void input_callback(const void *data, uint16_t len, const linkaddr_t *src, const linkaddr_t *dest) {
    printf("Callback triggered\n");
    printf("Received packet from %02x:%02x: '%.*s'\n", src->u8[0], src->u8[1], len, (char *)data);
}

PROCESS(nullnet_example_process, "NullNet Example");
AUTOSTART_PROCESSES(&nullnet_example_process);

PROCESS_THREAD(nullnet_example_process, ev, data) {
    static struct etimer periodic_timer;

    PROCESS_BEGIN();
    
    // Set up NullNet
    nullnet_buf = (uint8_t *)payload;
    nullnet_len = sizeof(payload);
    nullnet_set_input_callback(input_callback);
    printf("V1");

    etimer_set(&periodic_timer, CLOCK_SECOND * 5);

    while(1) {
        // Send packet every 5 seconds
        printf("Sending packet: '%s'\n", payload);
        printf("V2\n");
        NETSTACK_NETWORK.output(NULL); // Broadcast
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));
        etimer_reset(&periodic_timer);
    }

    PROCESS_END();
}