#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_

// #define IEEE802154_CONF_PANID 0xABCD
// Disable IPv6 and routing
// #define UIP_CONF_IPV6 0
// #define UIP_CONF_ROUTER 0

// // Disable sicslowpan
// #define NETSTACK_CONF_NETWORK nullnet_driver
#endif /* PROJECT_CONF_H_ */