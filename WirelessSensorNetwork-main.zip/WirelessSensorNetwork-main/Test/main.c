#include <stdint.h>

#include "sys/node-id.h"
#include "sys/log.h"
#include "sys/ctimer.h" 

#include "net/netstack.h"
#include "net/ipv6/simple-udp.h"
#include "net/routing/rpl-lite/rpl.h"
#include "net/routing/routing.h" 

#include "sht11-sensor.h"
//#include "contiki.h"

#include "lib/random.h"

#define LOG_MODULE "RLP"
#define LOG_LEVEL LOG_LEVEL_WARN

#define MAX_NODES 255
#define ENERGY_STARTINGPOINT 100   // Starting energy
#define ENERGY_THRESHOLD_LEVEL  20 // Minimum energy to participate ENERGY_THRESHOLD_LEVEL MIN_ENERGY
#define ENERGY_LOSS 1      // Energy loss per interval
#define MIN_RANDOM 60
#define MAX_RANDOM 100

#define STATUS_COORDINATOR  "COORDINATOR"
#define STATUS_MEMBER  "MEMBER"
#define STATUS_ORPHAN  "ORPHAN"

#define LEADER 1
#define WITH_SERVER_REPLY  1
#define UDP_CLIENT_PORT	8765
#define UDP_SERVER_PORT	5678

typedef enum {
    INIT_NODE_TYPE,
    STATE_MEMBER_NODE_START_LISTING,
    STATE_COORDINATOR_INITIAL_SETUP,
    STATE_COORDINATOR_SET_NEW_NODE,
    STATE_COORDINATOR_ACTION,
    STATE_MEMBER_IDLE,
    STATE_ORPHAN_IDLE,
    STATE_NODE_START_ELECTION,
    ENERGY_LOW,
    ENERGY_GONE,
} NodeState;

typedef enum {
    COORDINATOR,
    MEMBER,
    ORPHAN,
} NodeType;

typedef enum {
    ELECTION_NONE,         // No election is currently happening
    ELECTION_STARTED,
    ELECTION_IN_PROGRESS,      // An election is currently underway
    ELECTION_COMPLETED,        // The election has concluded successfully
    ELECTION_FAILED,            // The election has failed or timed out
} ElectionStatus;

// Enumeration for Received OK Status
typedef enum {
    RECEIVED_NO,         // Did not receive any OK messages
    PENDING,         // Waiting for OK messages
    RECEIVED_YES,            // Received at least one OK message
} ReceivedStatus;

typedef enum {
    PRESENT, 
    ABSENT,
} CoordinatorStatus;

typedef enum {
    MSG_ELECTION, 
    MSG_OK, 
    MSG_COORDINATOR, 
    MSG_HEART,
} MSG;

typedef struct {
    uint8_t node_ids[MAX_NODES];
    uint8_t count;
} node_list_t;

typedef struct {
    uint8_t id;
    CoordinatorStatus status;
} coordinator_node_t;

typedef struct {
    uint16_t id; // OWN ID
    uint8_t energy;
} node_t;

typedef struct {
    struct etimer *timer;
    struct ctimer *e_timer;
    clock_time_t heartbeat;
} timer_data_t;

typedef struct {
    node_t node;
    coordinator_node_t coordinator;
    NodeType type;
    NodeState currentState;
    ElectionStatus election;
    ReceivedStatus received;
} election_data_t;

typedef struct {
    float temperature;
    float humidity;
} measurements_t;

typedef struct {
    uint16_t sender_id;
    uint8_t sender_energy;
} sender_node_data_t;

typedef struct {
    MSG type;
    meta_data_t meta;
    measurements_t measurements;
} msg_t; // Extend message to include temperature

typedef struct {
    timer_data_t *timer;
    election_data_t *election_data;
    msg_t *msg;
} container_t; 

static void readSensors(measurements_t *measurements);
static float convertToCelsius(float temperature);
static float convertToHumidity(float humidity);

void rx_callback(struct simple_udp_connection *c,
                        const uip_ipaddr_t *sender,
                        uint16_t port,
                        const uip_ipaddr_t *receiver,
                        uint16_t recv_port,
                        const uint8_t *data,
                        uint16_t len);

// static void start_client_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer);
// static void start_server_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer);

//static void setupCooridnator(election_data_t *election_data, timer_data_t *timer);

// Function to handle regular coordinator actions and trigger elections if needed
static void step_down_as_coordinator(election_data_t *election_data);

static bool is_orphan(election_data_t *election_data);

static bool is_member(election_data_t *election_data);

static void should_start_election(election_data_t *election_data, const timer_data_t *timer_data);

static void decide_node_type(election_data_t* election_data, timer_data_t *timer_data);

// static void send(uint16_t to, msg_t *msg);
// static void broadcast(MSG type, uint16_t start, uint16_t end, node_t *node);
void rx_callback(struct simple_udp_connection *c,
                 const uip_ipaddr_t *sender,
                 uint16_t port,
                 const uip_ipaddr_t *receiver,
                 uint16_t recv_port,
                 const uint8_t *data,
                 uint16_t len);

static void handle_msg_election(msg_t *msg, election_data_t *election_data, timer_data_t *timer);
void handle_msg_election(msg_t *msg, election_data_t *election_data, timer_data_t *timer) ;
void handle_msg_ok(msg_t *msg, election_data_t *election);
void handle_msg_coordinator(msg_t *msg, election_data_t *election_data, timer_data_t *timer);        
void handle_msg_heart(msg_t *msg, election_data_t *election, timer_data_t *timer);                   

void log_scaled_value(const char *label, float scaled_value, const char *unit);
void log_step_down(const election_data_t *election_data);

bool is_low_energy(election_data_t *election_data); 
bool has_sufficient_energy(election_data_t *election_data);
void decrease_energy(election_data_t *election_data);


void start_election(election_data_t *election_data, timer_data_t *timer);

void handle_election_timeout(election_data_t *election_data);

bool is_election_inprogress(const election_data_t *election_data);

static bool has_not_received_ack(const election_data_t *election_data);

static void election_state(election_data_t *election_data);

//static void election_reviced_ack(election_data_t *election_data);

static bool is_sender_stronger_than_current_node(const election_data_t *election_data, msg_t *msg); 

//static bool is_sender_weaker_than_current_node(const election_data_t *election_data, msg_t *msg);

static bool is_sender_weaker_than_coordinator_node(const election_data_t *election_data, msg_t *msg);

static bool is_sender_coordinator(const election_data_t *election_data, msg_t *msg);

void set_coordinator(election_data_t *election_data);

void reset_coordinator_to_member(election_data_t *election_data);


PROCESS(bully_process, "Bully");
AUTOSTART_PROCESSES(&bully_process);

election_data_t election_data;
timer_data_t timer_data;
measurements_t measurements;

static struct etimer timer;
static struct ctimer e_timer;

static struct simple_udp_connection udp_server_conn;
static struct simple_udp_connection udp_client_conn;
static uip_ipaddr_t dest_ipaddr;

PROCESS_THREAD(bully_process, ev, data) {
    PROCESS_BEGIN();

    random_init((unsigned short)node_id);
    election_data.node.id = node_id; // Assign appropriate node_id
    election_data.coordinator.id = 0; 
    election_data.coordinator.status = ABSENT;
    election_data.node.energy = MIN_RANDOM + (random_rand() % (MAX_RANDOM - MIN_RANDOM + 1));;
    election_data.type = ORPHAN;
    election_data.election = ELECTION_NONE;
    election_data.received = RECEIVED_NO;
    election_data.currentState = INIT_NODE_TYPE;

    timer_data.timer = &timer;
    timer_data.e_timer = &e_timer;
    timer_data.heartbeat = clock_time();
    SENSORS_ACTIVATE(sht11_sensor);
    
    while(1) {
        switch (election_data.currentState)
        {
        case INIT_NODE_TYPE:
            //LOG_INFO("[N%d] STATE Deciding Node Type... (E:%d)\n", election_data.node.id, election_data.node.energy);
            decide_node_type(&election_data, &timer_data);
            break;    

        case STATE_MEMBER_NODE_START_LISTING:
            //LOG_INFO("[N%d] STATE Start Node Listen... (E:%d)\n", election_data.node.id, election_data.node.energy);
            simple_udp_register(&udp_client_conn, UDP_CLIENT_PORT, NULL, UDP_SERVER_PORT, rx_callback);
    
            etimer_set(timer_data.timer, CLOCK_SECOND * (5 + (election_data.node.id % 5)));
            election_data.currentState = STATE_MEMBER_IDLE;
            break;
        
        case STATE_COORDINATOR_INITIAL_SETUP:
            //LOG_INFO("[N%d] STATE Coordinator Initialises... (E:%d)\n", election_data.node.id, election_data.node.energy);
            NETSTACK_ROUTING.root_start();
            simple_udp_register(&udp_server_conn, UDP_SERVER_PORT, NULL, UDP_CLIENT_PORT, rx_callback);
    
            //setupCooridnator(&election_data, &timer_data);
            set_coordinator(&election_data);
            //start_client_listening(&udp_conn, &election_data.node, timer_data.timer);
            uip_ip6addr(&dest_ipaddr, 0xfd00,0,0,0x212,0x7401,0x1,0x101,0x1); // why???
            break;

        case STATE_COORDINATOR_SET_NEW_NODE:
            // How to set new coordinator?
            break;

        case STATE_COORDINATOR_ACTION:
            //LOG_WARN("[N%d] STATE Coordination Action... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_low_energy(&election_data))
                step_down_as_coordinator(&election_data);
            //handle_network_communication(&tx_count, &rx_count, &missed_tx_count, &udp_conn, str, sizeof(str), &dest_ipaddr);

            break;

        case STATE_MEMBER_IDLE:
            //LOG_WARN("[N%d] STATE Member... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_orphan(&election_data))
                break;

            // READ DATA FROM SENSORS
            readSensors(&measurements);
            // SEND DATA 
            measurements.temperature = convertToCelsius(measurements.temperature);
            measurements.humidity = convertToHumidity(measurements.humidity);
            log_scaled_value("Temperature", measurements.temperature, "°C");
            log_scaled_value("Humidity", measurements.humidity, "%");
            

            //broadcast(MSG_HEART, 1, election_data.node.id - 1, &election_data.node);
            break;

        case STATE_ORPHAN_IDLE:
            LOG_WARN("[N%d] STATE Orphan... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_member(&election_data))
                should_start_election(&election_data, &timer_data);
            
            //broadcast(MSG_HEART, 1, election_data.node.id - 1, &election_data.node);
            break;

        case STATE_NODE_START_ELECTION:
            //LOG_INFO("[N%d] STATE Election: Starting election... (E:%d)\n", election_data.node.id, election_data.node.energy);
            start_election(&election_data, &timer_data);
            //simple_udp_sendto(&udp_client_conn, str, strlen(str), &dest_ipaddr);
            if(NETSTACK_ROUTING.node_is_reachable() &&
               NETSTACK_ROUTING.get_root_ipaddr(&dest_ipaddr)) {
            msg_t msg = {
                        .type = MSG_ELECTION,
                        .meta = { .sender_id = election_data.node.id, .sender_energy = election_data.node.energy } // Should be own energy source?
            };

            simple_udp_sendto(&udp_client_conn, &msg, sizeof(msg_t), &dest_ipaddr);
            }
            break;

        case ENERGY_LOW:
            //LOG_INFO("[N%d] STATE Energy Low... (E:%d)\n", election_data.node.id, election_data.node.energy);

            break;
        case ENERGY_GONE:
            //LOG_INFO("[N%d] STATE Energy Gone...\n", election_data.node.id);
            break;

        default:
            //LOG_INFO("[N%d] Unknown state: %d\n", election_data.node.id, election_data.currentState);
            break;
        }

        decrease_energy(&election_data);
        //log_metadata(&election_data);   
     
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(timer_data.timer));
        //etimer_reset(timer_data.timer);
        // Reset the main event timer if expired
        etimer_reset(timer_data.timer);
    }
    
    PROCESS_END();
}

bool has_timeout_occurred(clock_time_t last_heartbeat, uint16_t timeout_seconds) {
    // Calculate the timeout duration in clock ticks
    clock_time_t timeout_ticks = timeout_seconds * CLOCK_SECOND;

    // Check if the current time exceeds the last heartbeat + timeout duration
    return (clock_time() - last_heartbeat) > timeout_ticks;
}

void update_heartbeat(timer_data_t* timer) {
    timer->heartbeat = clock_time();  
}

static void readSensors(measurements_t *measurements) {
  // Read temperature and humidity from the SHT11 sensor
  measurements->temperature = sht11_sensor.value(SHT11_SENSOR_TEMP);
  measurements->humidity = sht11_sensor.value(SHT11_SENSOR_HUMIDITY);
}

// Convert raw values to human-readable format (example conversion)
static float convertToCelsius(float temperature){
  return ((temperature / 10) - 396) / 10;
}

static float convertToHumidity(float humidity){
   // Constants for 12-bit resolution humidity calculation
  const float c1 = -2.0468;
  const float c2 = 0.0367;
  const float c3 = -1.5955e-6;

  // Calculate linear relative humidity using the formula
  float RH_linear = c1 + (c2 * humidity) + (c3 * humidity * humidity); // pow(humidity, 2)

  // Clamp RH to a maximum of 100% if it exceeds physical limits
  if (RH_linear > 100) {
    RH_linear = 100;
  }

  return RH_linear;
}


bool is_low_energy(election_data_t *election_data) {
    if (election_data->node.energy > ENERGY_THRESHOLD_LEVEL) return false;

    election_data->currentState = ENERGY_LOW;
    return true;
}

bool has_sufficient_energy(election_data_t *election_data) {
    if (election_data->node.energy > ENERGY_THRESHOLD_LEVEL) return true;

    election_data->currentState = ENERGY_LOW;

    return false;
}

void decrease_energy(election_data_t *election_data) {
    if (election_data->node.energy <= ENERGY_LOSS) {
        election_data->currentState = ENERGY_GONE;
        // Prevent underflow
        return;
    }

    election_data->node.energy -= ENERGY_LOSS;
}



void start_election(election_data_t *election_data, timer_data_t *timer) {    
    // Fast return if already in an election or insufficient energy
    if (election_data->election == ELECTION_IN_PROGRESS || 
        is_low_energy(election_data)) return;
    
    election_data->election = ELECTION_STARTED;
    election_data->received = PENDING;
    election_state(election_data);

    msg_t msg = {
                        .type = MSG_ELECTION,
                        .meta = { .sender_id = election_data->node.id, .sender_energy = election_data->node.energy } // Should be own energy source?
            };

    simple_udp_sendto(&udp_client_conn, &msg, sizeof(msg_t), &dest_ipaddr);

    ctimer_set((timer->e_timer), CLOCK_SECOND * 5, (void (*)(void *))handle_election_timeout, election_data);
}

void handle_election_timeout(election_data_t *election_data) {
    if (is_low_energy(election_data) ||
        is_election_inprogress(election_data) ||
        has_not_received_ack(election_data)) return;

    election_data->election = ELECTION_COMPLETED;
    election_data->type = COORDINATOR;
    election_data->coordinator.id = election_data->node.id;

    //broadcast(MSG_COORDINATOR, 1, election_data->node.id - 1, &election_data->node);
    msg_t msg = {
                    .type = MSG_COORDINATOR,
                    .meta = { .sender_id = election_data->node.id, .sender_energy = election_data->node.energy } // Should be own energy source?
        };
    simple_udp_sendto(&udp_client_conn, &msg, sizeof(msg_t), &dest_ipaddr);


    election_state(election_data);
    //LOG_INFO("[N%d] Won election (E:%d)\n", election_data->node.id, election_data->node.energy);
    //log_metadata(election_data);
}

bool is_election_inprogress(const election_data_t *election_data) {
    return election_data->election == ELECTION_IN_PROGRESS;
}

static bool has_not_received_ack(const election_data_t *election_data) {
    return election_data->received != RECEIVED_YES;
}

static void election_state(election_data_t *election_data){
    switch (election_data->election)
        {
        case ELECTION_COMPLETED:
            // Election completed. WHY become the leader/coordinator? 
            //LOG_INFO("[N%d] Election completed. Becoming coordinator.\n", election_data->node.id);
            //election_data.currentState = STATE_COORDINATOR;
            break;
        
        case ELECTION_STARTED:
            //LOG_INFO("[N%d] Election started.\n", election_data->node.id);
            //LOG_INFO("[N%d] Starting election (E:%d)\n", election_data->node.id, election_data->node.energy);
            //election_data.currentState = STATE_ELECTION;
            election_data->election = ELECTION_IN_PROGRESS;
            break;

        case ELECTION_IN_PROGRESS:
            //LOG_INFO("[N%d] Election in process.\n", election_data->node.id);
            //election_data.currentState = STATE_COORDINATOR;
            break;

        case ELECTION_FAILED:
            // Election failed. Start new election.
            //LOG_INFO("[N%d] Election failed. Starting new election.\n", election_data->node.id);
            //election_data.currentState = STATE_ELECTION;
            break;

        default:
            break;
        }

    return;
}



static bool is_sender_stronger_than_current_node(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id) < election_data->node.id;
}

// static bool is_sender_weaker_than_current_node(const election_data_t *election_data, msg_t *msg) {
//     return (msg->meta.sender_id) > election_data->node.id;
// }

static bool is_sender_weaker_than_coordinator_node(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id) <= election_data->coordinator.id;
}

static bool is_sender_coordinator(const election_data_t *election_data, msg_t *msg) {
    return (msg->meta.sender_id == election_data->coordinator.id);
}

void set_coordinator(election_data_t *election_data){
    election_data->coordinator.id = election_data->node.id;
    election_data->coordinator.status = PRESENT;
    election_data->currentState = STATE_COORDINATOR_ACTION;
}

void reset_coordinator_to_member(election_data_t *election_data) {
    // Remove the election_data->coordinator = 0
    election_data->coordinator.id = election_data->node.id;
    election_data->coordinator.status = ABSENT;
    election_data->currentState = STATE_ORPHAN_IDLE;
}



// Function to handle regular coordinator actions and trigger elections if needed
static void step_down_as_coordinator(election_data_t *election_data) {
    //LOG_INFO("[N%d] Stepping down: low energy (%d)\n", election_data->node.id, election_data->node.energy);
    reset_coordinator_to_member(election_data);
    //broadcast(MSG_ELECTION, election_data->node.id + 1, 255, &election_data->node);

    msg_t msg = {
                        .type = MSG_ELECTION,
                        .meta = { .sender_id = election_data->node.id, .sender_energy = election_data->node.energy } // Should be own energy source?
            };

    simple_udp_sendto(&udp_client_conn, &msg, sizeof(msg_t), &dest_ipaddr);
}

static bool is_orphan(election_data_t *election_data) {
    LOG_DBG("Checking if node is orphan: coordinator.stats=%d\n", election_data->coordinator.status);

    if (election_data->coordinator.status == PRESENT) return false;

    LOG_DBG("Node is orphan. Transitioning to STATE_ORPHAN_IDLE.\n");
    election_data->currentState = STATE_ORPHAN_IDLE;
    election_data->type = ORPHAN;
    return true;
}

static bool is_member(election_data_t *election_data) {
    LOG_DBG("Checking if node is member: coordinator.status=%d\n", election_data->coordinator.status);

    if (election_data->coordinator.status == ABSENT) return false;

    LOG_DBG("Node is member. Transitioning to STATE_MEMBER_IDLE.\n");
    election_data->currentState = STATE_MEMBER_IDLE;
    election_data->type = MEMBER;
    return false;
}


static void should_start_election(election_data_t *election_data, const timer_data_t *timer_data) {
    // Return early if an election is already in progress
    if (election_data->election == ELECTION_IN_PROGRESS) return;

    // Return early if the heartbeat has not timed out
    if (!has_timeout_occurred(timer_data->heartbeat, 30)) return;
    
    election_data->currentState = STATE_NODE_START_ELECTION;
}

static void decide_node_type(election_data_t* election_data, timer_data_t *timer_data){

    uint8_t leader = 1;

    if (election_data->node.id == leader) {
        election_data->currentState = STATE_COORDINATOR_INITIAL_SETUP;
    } else {
        election_data->currentState = STATE_MEMBER_NODE_START_LISTING;
    }
    etimer_set(timer_data->timer, CLOCK_SECOND * 10);
    // switch (election_data->node.id)
    // {
    //     case LEADER: // Now LEADER is a compile-time constant
    //         election_data->currentState = STATE_COORDINATOR;
    //         break;

    //     default:
    //         election_data->currentState = STATE_START_LISTING;
    //         break;
    // }
}



void log_scaled_value(const char *label, float scaled_value, const char *unit) {
    // Multiply by 100 to shift two decimal places
    int scaled_value_int = (int)(scaled_value * 100);

    // Print the label, integer part, and fractional part
    LOG_INFO("%s: %d.%02d%s\n", 
           label,
           scaled_value_int / 100,     // Integer part
           scaled_value_int % 100,     // Fractional part
           unit);                      // Unit (e.g., "%", "°C")
}

void log_step_down(const election_data_t *election_data) {
    //LOG_INFO("[N%d] Stepping down: low energy (%d)\n", election_data->node.id, election_data->node.energy);
}

void handle_msg_election(msg_t *msg, election_data_t *election_data, timer_data_t *timer) {
    if (is_sender_weaker_than_coordinator_node(election_data, msg) && has_sufficient_energy(election_data)) return;
    
    //LOG_INFO("[N%d] Got election from N%d (E:%d)\n", election_data->node.id, msg->meta.sender_id, msg->meta.sender_energy);
    
    // Send OK message to the sender of the election message
    msg_t response = {
        .type = MSG_OK,
        .meta = { .sender_id = election_data->node.id, .sender_energy = election_data->node.energy }
    };
    //send(msg->meta.sender_id, &response);  
    simple_udp_sendto(&udp_client_conn, &response, sizeof(msg_t), &dest_ipaddr);

 
    election_data->currentState = STATE_NODE_START_ELECTION; // Start new election  
}

void handle_msg_ok(msg_t *msg, election_data_t *election_data) {
    if (!is_election_inprogress(election_data) || is_sender_stronger_than_current_node(election_data, msg)) return;
    
    //LOG_INFO("[N%d] Got OK from N%d (E:%d)\n", election_data->node.id, msg->meta.sender_id, msg->meta.sender_energy);
    election_data->received = RECEIVED_YES;
    election_data->election = ELECTION_COMPLETED;

    election_data->currentState = STATE_MEMBER_IDLE; 
}

void handle_msg_coordinator(msg_t *msg, election_data_t *election_data, timer_data_t *timer) {
    if (is_sender_weaker_than_coordinator_node(election_data, msg)) return;
    election_data->currentState = STATE_COORDINATOR_SET_NEW_NODE;

    set_coordinator(election_data);
    election_data->election = ELECTION_COMPLETED;  // Stop any ongoing elections

    update_heartbeat(timer);

    ctimer_stop(timer->e_timer); // Stop the election timeout timer

    //LOG_INFO("[N%d] New coord N%d (E:%d)\n", election_data->node.id, election_data->coordinator.id, msg->meta.sender_energy);
    //log_metadata(election_data); 
}

void handle_msg_heart(msg_t *msg, election_data_t *election_data, timer_data_t *timer) {
    // Fast return if heartbeat is not from the current coordinator
    if (!is_sender_coordinator(election_data, msg)) return;

    update_heartbeat(timer); 

    // Prevents logging if the current node is the coordinator itself.
    if (msg->meta.sender_id == election_data->node.id) return;
    
    //LOG_INFO("[N%d] Heartbeat from N%d (E:%d)\n", election_data->node.id, election_data->coordinator.id, msg->meta.sender_energy);
}

void rx_callback(struct simple_udp_connection *c,
                 const uip_ipaddr_t *sender,
                 uint16_t port,
                 const uip_ipaddr_t *receiver,
                 uint16_t recv_port,
                 const uint8_t *data,
                 uint16_t len) {
    //LOG_WARN("Received message from %d\n", sender->u8[sizeof(uip_ipaddr_t) - 1]);
    // LOG_INFO_6ADDR(sender);
    // LOG_INFO_("\n");
    //if(len != sizeof(msg_t)) return;


    // Should only send messsage contain state what to do and what the other nodes id and energy. The rest should be handled by the node itself
    msg_t *msg = (msg_t *)data;
    //msg_t *msg = content->msg;
    // election_data_t *election_data = content->election_data;
    // timer_data_t *timer = content->timer;

    switch (msg->type) {
        case MSG_ELECTION:
            handle_msg_election(msg, &election_data, &timer_data);
            break;

        case MSG_OK:
            handle_msg_ok(msg, &election_data);
            break;

        case MSG_COORDINATOR:
            handle_msg_coordinator(msg, &election_data, &timer_data);
            break;

        case MSG_HEART:
            handle_msg_heart(msg, &election_data, &timer_data);
            break;

        default:
            //LOG_INFO("Unknown message type: %d\n", msg->type);
            break;
    }
}


// static void start_client_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer){
//     //simple_udp_register(conn, UDP_PORT, NULL, UDP_PORT, rx_callback); // WHY ON THE SAME PORT?
//     simple_udp_register(conn, UDP_CLIENT_PORT, NULL,
//                       UDP_SERVER_PORT, rx_callback);
    
//     etimer_set(timer, CLOCK_SECOND * (5 + (node->id % 5)));

//     return;
// }

// static void start_server_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer){
//     //simple_udp_register(conn, UDP_PORT, NULL, UDP_PORT, rx_callback); // WHY ON THE SAME PORT?
//     simple_udp_register(conn, UDP_SERVER_PORT, NULL,
//                       UDP_CLIENT_PORT, rx_callback);
    
//     etimer_set(timer, CLOCK_SECOND * (5 + (node->id % 5)));

//     return;
// }

// void setupCooridnator(election_data_t *election_data, timer_data_t *timer_data){
//     // Setup RPL for node 1
    
//     //election_data.node.id = id;
//     // uip_ipaddr_t ipaddr;
//     // uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 1);
//     // uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);
    
//     // rpl_dag_init_root(RPL_DEFAULT_INSTANCE, &ipaddr, &ipaddr, 64, 0);
//     NETSTACK_ROUTING.root_start();
//     return;
// }


// void node_actions(election_data_t *election){
//     // Each node should perform the following actions:
//     // if(election_data.coordinator == election_data.node.id) {
//     //             election_data.currentState = STATE_COORDINATOR_OPERATING;
//     //         } else {
//     //             election_data.currentState = STATE_IDLE;
//     //         }
//     // New implemtation should do the same
//     switch (election.type) 
//     {
//     case STATE_COORDINATOR:
//         election.currentState = STATE_COORDINATOR_OPERATING;
//         break;
//     case STATE_MEMBER:
//         election.currentState = STATE_IDLE;
//         break;
//     case STATE_ORPHAN:
//         election.currentState = START_ELECTION;
//         break;
//     default:
//         break;
//     }
// }

// static void election_reviced_ack(election_data_t *election_data){
//     switch (election_data->received)
//         {
//         case RECEIVED_YES:
//             //LOG_INFO("[N%d] Received OK. Waiting for coordinator announcement.\n", election_data->node.id);
//             election_data->currentState = STATE_MEMBER_IDLE;
//             break;

//         case RECEIVED_NO:
//             //LOG_INFO("[N%d] Received NO.", election_data->node.id);    
//             break;

//         case RECEIVED_PENDING:
//             //LOG_INFO("[N%d] Waiting for response NO.", election_data->node.id);    
//             break;    

//         default:
//             break;
//         }

//     return;
// }