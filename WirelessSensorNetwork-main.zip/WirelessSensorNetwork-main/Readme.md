# Files and folder structure 
The folder structure is we are have different version in different folder. Our final project is going to be in the folder named Project.

- SimpleRLP is the (not working)
- RLP_MAS is the  (not working)
- RLP_MAS_v1.01 is working. It the implementation from Kevin
- RLP_MAS_v1.02 is a same implementation as RLP_MAS_v1.01 however is now independent from the operating system
- RLP_MAS_v.03 is using the RPL-lite version


## Progress

- [ ] Make a tempatur sensor and test it works in Cooja and on Bmote
- [ ] Make the First RLP Multi agant system
- [ ] Look in to the energy expensive of sending to different notes. 
  - [ ] Is there a way to optimise the which note talk to which? 
  - [ ] Argument for our dicision 
- [ ] 