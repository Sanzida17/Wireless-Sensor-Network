#include "contiki.h"
#include "net/rime/rime.h"
#include "random.h"
#include "lib/list.h"
#include "lib/memb.h"
#include <stdio.h>

#define ELECTION_MSG 1
#define VICTORY_MSG 2
#define OK_MSG 3

static int node_id; // Unique ID for each node
static int leader_id = -1; // Current leader ID

PROCESS(bully_election_process, "Bully Election Process");
AUTOSTART_PROCESSES(&bully_election_process);

/*---------------------------------------------------------------------------*/
static void broadcast_recv(struct broadcast_conn *c, const linkaddr_t *from) {
  int *msg = packetbuf_dataptr();

  if (*msg == ELECTION_MSG) {
    if (from->u8[0] < node_id) {
      // Send OK message back to the sender
      packetbuf_copyfrom(&OK_MSG, sizeof(int));
      broadcast_send(c);
    } else if (from->u8[0] > node_id && leader_id == -1) {
      // Start a new election if a higher ID is found and no leader is set
      packetbuf_copyfrom(&ELECTION_MSG, sizeof(int));
      broadcast_send(c);
    }
  } else if (*msg == VICTORY_MSG) {
    leader_id = from->u8[0];
    printf("Node %d: New leader is %d\n", node_id, leader_id);
  } else if (*msg == OK_MSG) {
    // Received OK message, do nothing for now
  }
}

static const struct broadcast_callbacks broadcast_call = {broadcast_recv};
static struct broadcast_conn broadcast;
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(bully_election_process, ev, data) {
  static struct etimer et;

  PROCESS_EXITHANDLER(broadcast_close(&broadcast);)
  
  PROCESS_BEGIN();

  node_id = linkaddr_node_addr.u8[0]; // Assign unique ID based on node address
  printf("Node %d started\n", node_id);

  broadcast_open(&broadcast, 129, &broadcast_call);

  while (1) {
    etimer_set(&et, CLOCK_SECOND * 10 + random_rand() % (CLOCK_SECOND * 10));

    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));

    if (leader_id == -1 || random_rand() % 10 < 2) { // Randomly trigger elections
      printf("Node %d: Initiating election\n", node_id);
      packetbuf_copyfrom(&ELECTION_MSG, sizeof(int));
      broadcast_send(&broadcast);
    }
  }

  PROCESS_END();
}



// #include <stdint.h>

// #include "sys/node-id.h"
// #include "contiki.h"
// #include "net/rime/rime.h"
// #include <stdio.h>
// #include "sht11-sensor.h"
// //#include "contiki.h"

// #include "lib/random.h"

// static int node_id; // Unique ID for each node
// static int leader_id = -1; // Current leader ID

// static struct etimer leader_timer;
// #define UDP_PORT 1234
// static struct simple_udp_connection udp_conn;

// void start_election() {
//     // Send election message to nodes with higher IDs
//     // Assume you have a list of node addresses and your own node_id
//     uip_ipaddr_t destination_ipaddr;
//     char election_msg[] = "ELECTION";

//     // Send election message to all nodes with higher IDs
//     for (int i = 0; i < num_nodes; i++) {
//         if (nodes[i].id > node_id) {
//             // Set destination IP address for the node with higher ID
//             uip_ip6addr(&destination_ipaddr, ...); // Set appropriate address
//             simple_udp_sendto(&udp_conn, election_msg, sizeof(election_msg), &destination_ipaddr);
//         }
//     }
// }


// void announce_coordinator() {
//     // Send coordinator message to all nodes
//     char coordinator_msg[] = "COORDINATOR";
    
//     // Broadcast coordinator message to all nodes
//     for (int i = 0; i < num_nodes; i++) {
//         uip_ip6addr(&destination_ipaddr, ...); // Set appropriate address
//         simple_udp_sendto(&udp_conn, coordinator_msg, sizeof(coordinator_msg), &destination_ipaddr);
//     }
// }

// static void udp_rx_callback(struct simple_udp_connection *c,
//                             const uip_ipaddr_t *sender_addr,
//                             uint16_t sender_port,
//                             const uip_ipaddr_t *receiver_addr,
//                             uint16_t receiver_port,
//                             const uint8_t *data,
//                             uint16_t datalen) {
//     char msg[datalen + 1];
//     memcpy(msg, data, datalen);
//     msg[datalen] = '\0';

//     if (strcmp(msg, "ELECTION") == 0) {
//         // Received an election message
//         printf("Node %d received ELECTION from %u\n", node_id, sender_addr->u8[15]);

//         if (node_id > sender_addr->u8[15]) {
//             // Respond with OK if this node has a higher ID
//             char ok_msg[] = "OK";
//             simple_udp_sendto(&udp_conn, ok_msg, sizeof(ok_msg), sender_addr);

//             // Start a new election if not already started
//             start_election();
//         }
//     } else if (strcmp(msg, "OK") == 0) {
//         // Received an OK message
//         printf("Node %d received OK from %u\n", node_id, sender_addr->u8[15]);
        
//         // This means there's a higher ID node alive, wait for its coordinator message
//     } else if (strcmp(msg, "COORDINATOR") == 0) {
//         // Received a coordinator message
//         printf("Node %d received COORDINATOR from %u\n", node_id, sender_addr->u8[15]);

//         leader_id = sender_addr->u8[15]; // Update leader ID
//     }
// }

// PROCESS(bully_process, "Bully");
// AUTOSTART_PROCESSES(&bully_process);

// static struct ctimer e_timer;



// PROCESS_THREAD(bully_process, ev, data) {
//     PROCESS_BEGIN();
//     simple_udp_register(&udp_conn, UDP_PORT, NULL, UDP_PORT, udp_rx_callback);
    
//     while (1) {
//         // Check for leader timeout and initiate election if needed
//         etimer_set(&leader_timer, CLOCK_SECOND * LEADER_TIMEOUT_INTERVAL);

//         PROCESS_WAIT_EVENT();

//         if (ev == PROCESS_EVENT_TIMER && data == &leader_timer) {
//             // Check if leader is alive
//             if (!is_leader_alive()) {
//                 start_election();
//             }
//             etimer_reset(&leader_timer);
//         }
//     }

//     PROCESS_END();
// }
