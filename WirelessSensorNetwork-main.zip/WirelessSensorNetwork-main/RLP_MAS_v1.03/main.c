#include <stdio.h>

#include "inc/bully.h"
#include "inc/election.h"
#include "inc/energy.h"
#include "inc/logs.h"
#include "inc/messages.h"
#include "inc/network_msg.h"
#include "inc/node_management.h"
#include "inc/status_strings.h"
#include "inc/sensors_helper.h"
#include "inc/timer_helper.h"
#include "inc/types.h"
#include "lib/random.h"

PROCESS(bully_process, "Bully");
AUTOSTART_PROCESSES(&bully_process);

election_data_t election_data;
timer_data_t timer_data;
measurements_t measurements;

static struct etimer timer;
static struct ctimer e_timer;
//static linkaddr_t dest_addr;

void input_callback(const void *data, uint16_t len, const linkaddr_t *src, const linkaddr_t *dest) {
    LOG_INFO("Received message from %d\n", src->u8[sizeof(uip_ipaddr_t) - 1]);
    //LOG_INFO_6ADDR(src);
    LOG_INFO_("\n");
    //if(len != sizeof(msg_t)) return;

    container_t *content = (container_t *)data;
    msg_t *msg = content->msg;
    election_data_t *election_data = content->election_data;
    timer_data_t *timer = content->timer;

    switch (msg->type) {
        case MSG_ELECTION:
            handle_msg_election(msg, election_data, timer);
            break;

        case MSG_OK:
            handle_msg_ok(msg, election_data);
            break;

        case MSG_COORDINATOR:
            handle_msg_coordinator(msg, election_data, timer);
            break;

        case MSG_HEART:
            handle_msg_heart(msg, election_data, timer);
            break;

        default:
            LOG_WARN("Unknown message type: %d\n", msg->type);
            break;
    }
}

PROCESS_THREAD(bully_process, ev, data) {
    PROCESS_BEGIN();
    static char str[32];
    // uip_ipaddr_t dest_ipaddr;
    // static uint32_t tx_count;
    //static uint32_t missed_tx_count;

    random_init((unsigned short)node_id);
    election_data.node.id = node_id; // Assign appropriate node_id
    election_data.coordinator.id = 0; 
    election_data.coordinator.status = ABSENT;
    election_data.node.energy = MIN_RANDOM + (random_rand() % (MAX_RANDOM - MIN_RANDOM + 1));;
    election_data.type = STATE_ORPHAN;
    election_data.election = ELECTION_NONE;
    election_data.received = RECEIVED_NO;
    election_data.currentState = STATE_DECIDE_NODE_TYPE;

    timer_data.timer = &timer;
    timer_data.e_timer = &e_timer;
    timer_data.heartbeat = clock_time();
    SENSORS_ACTIVATE(sht11_sensor);
    
    while(1) {
        switch (election_data.currentState)
        {
        case STATE_DECIDE_NODE_TYPE:
            //LOG_INFO("[N%d] STATE Deciding Node Type... (E:%d)\n", election_data.node.id, election_data.node.energy);
            decide_node_type(&election_data, &timer_data);
            break;    

        case STATE_MEMBER_NODE_START_LISTING:
            //LOG_INFO("[N%d] STATE Start Node Listen... (E:%d)\n", election_data.node.id, election_data.node.energy);
            //simple_udp_register(&udp_client_conn, UDP_CLIENT_PORT, NULL, UDP_SERVER_PORT, udp_client_rx_callback);
    
            etimer_set(timer_data.timer, CLOCK_SECOND * (5 + (election_data.node.id % 5)));
            election_data.currentState = STATE_MEMBER_IDLE;
            break;
        
        case STATE_COORDINATOR_INITIAL_SETUP:
            //LOG_INFO("[N%d] STATE Coordinator Initialises... (E:%d)\n", election_data.node.id, election_data.node.energy);
            // NETSTACK_ROUTING.root_start();
            // simple_udp_register(&udp_server_conn, UDP_SERVER_PORT, NULL, UDP_CLIENT_PORT, udp_server_rx_callback);
    
            // //setupCooridnator(&election_data, &timer_data);
            // set_coordinator(&election_data);
            // //start_client_listening(&udp_conn, &election_data.node, timer_data.timer);
            // uip_ip6addr(&dest_ipaddr, 0xfd00,0,0,0x212,0x7401,0x1,0x101,0x1); // why???
            break;

        case STATE_COORDINATOR_SET_NEW_NODE:
            // How to set new coordinator?
            break;

        case STATE_COORDINATOR_ACTION:
            //LOG_INFO("[N%d] STATE Coordination Action... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_low_energy(&election_data))
                step_down_as_coordinator(&election_data);
            //handle_network_communication(&tx_count, &rx_count, &missed_tx_count, &udp_conn, str, sizeof(str), &dest_ipaddr);
            msg_t s = {
                    .type = MSG_HEART,
                    .meta = { .sender_id = node.id, .sender_energy = node.energy }
                };

            nullnet_buf = (uint8_t *)&s;
            nullnet_len = sizeof(s);
            NETSTACK_NETWORK.output(NULL); // Broadcast
            break;

        case STATE_MEMBER_IDLE:
            //LOG_INFO("[N%d] STATE Member... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_orphan(&election_data))
                break;

            // READ DATA FROM SENSORS
            readSensors(&measurements);
            // SEND DATA 
            measurements.temperature = convertToCelsius(measurements.temperature);
            measurements.humidity = convertToHumidity(measurements.humidity);
            log_scaled_value("Temperature", measurements.temperature, "°C");
            log_scaled_value("Humidity", measurements.humidity, "%");
            
            break;

        case STATE_ORPHAN_IDLE:
            //LOG_INFO("[N%d] STATE Orphan... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_member(&election_data))
                should_start_election(&election_data, &timer_data);
            
            msg_t start_election_msg = {
                    .type = MSG_ELECTION,
                    .meta = { .sender_id = node.id, .sender_energy = node.energy }
                };

            nullnet_buf = (uint8_t *)&start_election_msg;
            nullnet_len = sizeof(start_election_msg);
            NETSTACK_NETWORK.output(NULL); // Broadcast// Broadcast
            break;

        case STATE_NODE_START_ELECTION:
            //LOG_INFO("[N%d] STATE Election: Starting election... (E:%d)\n", election_data.node.id, election_data.node.energy);
            start_election(&election_data, &timer_data);
            break;

        // case ENERGY_LOW:
        //     //LOG_INFO("[N%d] STATE Energy Low... (E:%d)\n", election_data.node.id, election_data.node.energy);

        //     break;
        // case ENERGY_GONE:
        //     //LOG_INFO("[N%d] STATE Energy Gone...\n", election_data.node.id);
        //     break;

        default:
            //LOG_WARN("[N%d] Unknown state: %d\n", election_data.node.id, election_data.currentState);
            break;
        }

        decrease_energy(&election_data);
        //log_metadata(&election_data);   
     
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(timer_data.timer));
        //etimer_reset(timer_data.timer);
        // Reset the main event timer if expired
        etimer_reset(timer_data.timer);
    }
    
    PROCESS_END();
}

