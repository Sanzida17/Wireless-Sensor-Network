#ifndef TYPES_H
#define TYPES_H
#include <stdint.h>
#include "sys/log.h"
#include "sys/ctimer.h" 
#include "net/nullnet/nullnet.h"
#include "net/netstack.h"

#define UDP_PORT 8765
#define LOG_MODULE "RLP"
#define LOG_LEVEL LOG_LEVEL_INFO

#define MAX_NODES 255
#define ENERGY_STARTINGPOINT 100   // Starting energy
#define ENERGY_THRESHOLD_LEVEL  20 // Minimum energy to participate ENERGY_THRESHOLD_LEVEL MIN_ENERGY
#define ENERGY_LOSS 1      // Energy loss per interval
#define MIN_RANDOM 60
#define MAX_RANDOM 100

typedef enum {
    STATE_DECIDE_NODE_TYPE,
    STATE_MEMBER_NODE_START_LISTING,
    STATE_COORDINATOR_INITIAL_SETUP,
    STATE_COORDINATOR_SET_NEW_NODE,
    STATE_COORDINATOR_ACTION,
    STATE_MEMBER_IDLE,
    STATE_ORPHAN_IDLE,
    STATE_NODE_START_ELECTION,
    STATE_ENERGY_LOW,
    STATE_ENERGY_GONE,
} NodeState;

typedef enum {
    STATE_COORDINATOR,
    STATE_MEMBER,
    STATE_ORPHAN,
} NodeType;

typedef enum {
    ELECTION_NONE,         // No election is currently happening
    ELECTION_STARTED,
    ELECTION_IN_PROGRESS,      // An election is currently underway
    ELECTION_COMPLETED,        // The election has concluded successfully
    ELECTION_FAILED,            // The election has failed or timed out
} ElectionStatus;

// Enumeration for Received OK Status
typedef enum {
    RECEIVED_NO,         // Did not receive any OK messages
    RECEIVED_PENDING,         // Waiting for OK messages
    RECEIVED_YES,            // Received at least one OK message
} ReceivedStatus;

typedef enum {
    PRESENT, 
    ABSENT,
} CoordinatorStatus;

typedef enum {
    MSG_ELECTION, 
    MSG_OK, 
    MSG_COORDINATOR, 
    MSG_HEART,
} MSG;

typedef struct {
    uint8_t node_ids[MAX_NODES];
    uint8_t count;
} node_list_t;

typedef struct {
    uint8_t id;
    CoordinatorStatus status;
} coordinator_node_t;

typedef struct {
    uint16_t id; // OWN ID
    uint8_t energy;
} node_t;

typedef struct {
    struct etimer *timer;
    struct ctimer *e_timer;
    clock_time_t heartbeat;
} timer_data_t;

typedef struct {
    node_t node;
    coordinator_node_t coordinator;
    NodeType type;
    NodeState currentState;
    ElectionStatus election;
    ReceivedStatus received;
} election_data_t;

typedef struct {
    float temperature;
    float humidity;
} measurements_t;

typedef struct {
    uint16_t sender_id;
    uint8_t sender_energy;
} meta_data_t;

typedef struct {
    MSG type;
    meta_data_t meta;
    measurements_t measurements;
} msg_t; // Extend message to include temperature

typedef struct {
    timer_data_t *timer;
    election_data_t *election_data;
    msg_t *msg;
} container_t; 

#endif /* TYPES_H */