#include "inc/node_management.h"


// void decrease_and_log_energy(election_data_t *election_data){
//     if (decrease_energy(election_data)) return;
    
//     log_metadata(election_data);   
// }

// Function to handle regular coordinator actions and trigger elections if needed
void step_down_as_coordinator(election_data_t *election_data) {
    LOG_INFO("[N%d] Stepping down: low energy (%d)\n", election_data->node.id, election_data->node.energy);
    reset_coordinator_to_member(election_data);
    msg_t start_election_msg = {
                    .type = MSG_ELECTION,
                    .meta = { .sender_id = node.id, .sender_energy = node.energy }
                };

    nullnet_buf = (uint8_t *)&start_election_msg;
    nullnet_len = sizeof(start_election_msg);
    NETSTACK_NETWORK.output(NULL); // Broadcast// Broadcast
}

bool is_orphan(election_data_t *election_data) {
    LOG_DBG("Checking if node is orphan: coordinator.stats=%d\n", election_data->coordinator.status);

    if (election_data->coordinator.status == PRESENT) return false;

    LOG_DBG("Node is orphan. Transitioning to STATE_ORPHAN_IDLE.\n");
    election_data->currentState = STATE_ORPHAN_IDLE;
    election_data->type = STATE_ORPHAN;
    return true;
}

bool is_member(election_data_t *election_data) {
    LOG_DBG("Checking if node is member: coordinator.status=%d\n", election_data->coordinator.status);

    if (election_data->coordinator.status == ABSENT) return false;

    LOG_DBG("Node is member. Transitioning to STATE_MEMBER_IDLE.\n");
    election_data->currentState = STATE_MEMBER_IDLE;
    election_data->type = STATE_MEMBER;
    return false;
}


void should_start_election(election_data_t *election_data, const timer_data_t *timer_data) {
    // Return early if an election is already in progress
    if (election_data->election == ELECTION_IN_PROGRESS) return;

    // Return early if the heartbeat has not timed out
    if (!has_timeout_occurred(timer_data->heartbeat, 30)) return;
    
    election_data->currentState = STATE_NODE_START_ELECTION;
}

void decide_node_type(election_data_t* election_data, timer_data_t *timer_data){

    uint8_t leader = 1;

    if (election_data->node.id == leader) {
        election_data->currentState = STATE_COORDINATOR_INITIAL_SETUP;
    } else {
        election_data->currentState = STATE_MEMBER_NODE_START_LISTING;
    }
    etimer_set(timer_data->timer, CLOCK_SECOND * 10);
    // switch (election_data->node.id)
    // {
    //     case LEADER: // Now LEADER is a compile-time constant
    //         election_data->currentState = STATE_COORDINATOR;
    //         break;

    //     default:
    //         election_data->currentState = STATE_START_LISTING;
    //         break;
    // }
}

// void node_actions(election_data_t *election){
//     // Each node should perform the following actions:
//     // if(election_data.coordinator == election_data.node.id) {
//     //             election_data.currentState = STATE_COORDINATOR_OPERATING;
//     //         } else {
//     //             election_data.currentState = STATE_IDLE;
//     //         }
//     // New implemtation should do the same
//     switch (election.type) 
//     {
//     case STATE_COORDINATOR:
//         election.currentState = STATE_COORDINATOR_OPERATING;
//         break;
//     case STATE_MEMBER:
//         election.currentState = STATE_IDLE;
//         break;
//     case STATE_ORPHAN:
//         election.currentState = START_ELECTION;
//         break;
//     default:
//         break;
//     }
// }




