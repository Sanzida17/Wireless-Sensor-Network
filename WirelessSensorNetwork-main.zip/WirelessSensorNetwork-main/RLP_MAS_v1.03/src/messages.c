#include "inc/messages.h"

void handle_msg_election(msg_t *msg, election_data_t *election_data, timer_data_t *timer) {
    if (is_sender_weaker_than_coordinator_node(election_data, msg) && has_sufficient_energy(election_data)) return;
    
    LOG_INFO("[N%d] Got election from N%d (E:%d)\n", election_data->node.id, msg->meta.sender_id, msg->meta.sender_energy);
    
    // Send OK message to the sender of the election message
    msg_t response = {
        .type = MSG_OK,
        .meta = { .sender_id = election_data->node.id, .sender_energy = election_data->node.energy }
    };
    //send(msg->meta.sender_id, &response);  
 
    election_data->currentState = STATE_NODE_START_ELECTION; // Start new election  
}

void handle_msg_ok(msg_t *msg, election_data_t *election_data) {
    if (!is_election_inprogress(election_data) || is_sender_stronger_than_current_node(election_data, msg)) return;
    
    LOG_INFO("[N%d] Got OK from N%d (E:%d)\n", election_data->node.id, msg->meta.sender_id, msg->meta.sender_energy);
    election_data->received = RECEIVED_YES;
    election_data->election = ELECTION_COMPLETED;

    election_data->currentState = STATE_MEMBER_IDLE; 
}

void handle_msg_coordinator(msg_t *msg, election_data_t *election_data, timer_data_t *timer) {
    if (is_sender_weaker_than_coordinator_node(election_data, msg)) return;
    election_data->currentState = STATE_COORDINATOR_SET_NEW_NODE;

    set_coordinator(election_data);
    election_data->election = ELECTION_COMPLETED;  // Stop any ongoing elections

    update_heartbeat(timer);

    ctimer_stop(timer->e_timer); // Stop the election timeout timer

    LOG_INFO("[N%d] New coord N%d (E:%d)\n", election_data->node.id, election_data->coordinator.id, msg->meta.sender_energy);
    //log_metadata(election_data); 
}

void handle_msg_heart(msg_t *msg, election_data_t *election_data, timer_data_t *timer) {
    // Fast return if heartbeat is not from the current coordinator
    if (!is_sender_coordinator(election_data, msg)) return;

    update_heartbeat(timer); 

    // Prevents logging if the current node is the coordinator itself.
    if (msg->meta.sender_id == election_data->node.id) return;
    
    LOG_INFO("[N%d] Heartbeat from N%d (E:%d)\n", election_data->node.id, election_data->coordinator.id, msg->meta.sender_energy);
}