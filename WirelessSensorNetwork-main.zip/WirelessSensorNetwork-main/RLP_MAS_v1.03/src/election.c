#include "inc/election.h"


void start_election(election_data_t *election_data, timer_data_t *timer) {    
    // Fast return if already in an election or insufficient energy
    if (election_data->election == ELECTION_IN_PROGRESS || 
        is_low_energy(election_data)) return;
    
    election_data->election = ELECTION_STARTED;
    //election_data->received = PENDING;
    election_state(election_data);

    Msg_t start_election_msg = {
                    .type = MSG_ELECTION,
                    .meta = { .sender_id = node.id, .sender_energy = node.energy }
                };

    nullnet_buf = (uint8_t *)&start_election_msg;
    nullnet_len = sizeof(start_election_msg);
    NETSTACK_NETWORK.output(NULL); // Broadcast// Broadcast

    ctimer_set((timer->e_timer), CLOCK_SECOND * 5, (void (*)(void *))handle_election_timeout, election_data);
}

void handle_election_timeout(election_data_t *election_data) {
    if (is_low_energy(election_data) ||
        is_election_inprogress(election_data) ||
        has_not_received_ack(election_data)) return;

    election_data->election = ELECTION_COMPLETED;
    election_data->type = STATE_COORDINATOR;
    election_data->coordinator.id = election_data->node.id;

    Msg_t start_election_msg = {
                .type = MSG_COORDINATOR,
                .meta = { .sender_id = node.id, .sender_energy = node.energy }
    };

    nullnet_buf = (uint8_t *)&start_election_msg;
    nullnet_len = sizeof(start_election_msg);
    NETSTACK_NETWORK.output(NULL); // Broadcast// Broadcast

    election_state(election_data);
    //LOG_INFO("[N%d] Won election (E:%d)\n", election_data->node.id, election_data->node.energy);
    //log_metadata(election_data);
}

bool is_election_inprogress(const election_data_t *election_data) {
    return election_data->election == ELECTION_IN_PROGRESS;
}

bool has_not_received_ack(const election_data_t *election_data) {
    return election_data->received != RECEIVED_YES;
}


void election_state(election_data_t *election_data){
    switch (election_data->election)
        {
        case ELECTION_COMPLETED:
            // Election completed. WHY become the leader/coordinator? 
            LOG_INFO("[N%d] Election completed. Becoming coordinator.\n", election_data->node.id);
            //election_data.currentState = STATE_COORDINATOR;
            break;
        
        case ELECTION_STARTED:
            LOG_INFO("[N%d] Election started.\n", election_data->node.id);
            LOG_INFO("[N%d] Starting election (E:%d)\n", election_data->node.id, election_data->node.energy);
            //election_data.currentState = STATE_ELECTION;
            election_data->election = ELECTION_IN_PROGRESS;
            break;

        case ELECTION_IN_PROGRESS:
            LOG_INFO("[N%d] Election in process.\n", election_data->node.id);
            //election_data.currentState = STATE_COORDINATOR;
            break;

        case ELECTION_FAILED:
            // Election failed. Start new election.
            LOG_INFO("[N%d] Election failed. Starting new election.\n", election_data->node.id);
            //election_data.currentState = STATE_ELECTION;
            break;

        default:
            break;
        }

    return;
}

void election_reviced_ack(election_data_t *election_data){
    switch (election_data->received)
        {
        case RECEIVED_YES:
            LOG_INFO("[N%d] Received OK. Waiting for coordinator announcement.\n", election_data->node.id);
            election_data->currentState = STATE_MEMBER_IDLE;
            break;

        case RECEIVED_NO:
            LOG_INFO("[N%d] Received NO.", election_data->node.id);    
            break;

        case PENDING:
            LOG_INFO("[N%d] Waiting for response NO.", election_data->node.id);    
            break;    

        default:
            break;
        }

    return;
}