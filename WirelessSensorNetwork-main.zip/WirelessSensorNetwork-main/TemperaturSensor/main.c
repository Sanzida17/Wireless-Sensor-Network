#include "contiki.h"
#include "sht11-sensor.h"
#include "sys/log.h"


#define LOG_MODULE "App"
#define LOG_LEVEL LOG_LEVEL_INFO

float convertToCelsius(float temperature);
float convertToHumidity(float humidity);
void print_scaled_value(const char *label, float scaled_value, const char *unit) ;

PROCESS(sensor_process, "Sensor Process");
AUTOSTART_PROCESSES(&sensor_process);

PROCESS_THREAD(sensor_process, ev, data)
{
  static struct etimer timer;

  PROCESS_BEGIN();

  etimer_set(&timer, CLOCK_SECOND * 1);
  SENSORS_ACTIVATE(sht11_sensor);

  while(1) {
    float temp = sht11_sensor.value(SHT11_SENSOR_TEMP); 
    float humidity = sht11_sensor.value(SHT11_SENSOR_HUMIDITY);

    temp = convertToCelsius(temp); 
    humidity = convertToHumidity(humidity);

    print_scaled_value("Temperature", temp, "°C");
    print_scaled_value("Humidity", humidity, "%");

    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&timer));
    etimer_reset(&timer);
  }

  PROCESS_END();
}

// Convert raw values to human-readable format (example conversion)
float convertToCelsius(float temperature){
  return ((temperature / 10) - 396) / 10;
}

float convertToHumidity(float humidity){
   // Constants for 12-bit resolution humidity calculation
  const float c1 = -2.0468;
  const float c2 = 0.0367;
  const float c3 = -1.5955e-6;

  // Calculate linear relative humidity using the formula
  float RH_linear = c1 + (c2 * humidity) + (c3 * humidity * humidity); // pow(humidity, 2)

  // Clamp RH to a maximum of 100% if it exceeds physical limits
  if (RH_linear > 100) {
    RH_linear = 100;
  }

  return RH_linear;
}


// Function to print a scaled value as a floating-point number with two decimal places
void print_scaled_value(const char *label, float scaled_value, const char *unit) {
    // Multiply by 100 to shift two decimal places
    int scaled_value_int = (int)(scaled_value * 100);

    // Print the label, integer part, and fractional part
    printf("%s: %d.%02d%s\n", 
           label,
           scaled_value_int / 100,     // Integer part
           scaled_value_int % 100,     // Fractional part
           unit);                      // Unit (e.g., "%", "°C")
}