#include "contiki.h"
#include "net/rime/rime.h"
#include "dev/leds.h"
#include "random.h"
#include <stdio.h>

#define MAX_NODES 5
#define ELECTION_CHANNEL 129
#define ALIVE_CHANNEL 130
#define COORDINATOR_CHANNEL 131

static struct broadcast_conn election_conn;
static struct broadcast_conn alive_conn;
static struct broadcast_conn coordinator_conn;

static int node_id;
static int leader_id = -1;
static int is_coordinator = 0;
static clock_time_t last_alive_time;

PROCESS(bully_process, "Bully Algorithm Process");
AUTOSTART_PROCESSES(&bully_process);

static void broadcast_recv(struct broadcast_conn *c, const linkaddr_t *from)
{
  // Handle received messages
}

static const struct broadcast_callbacks broadcast_call = {broadcast_recv};

static void send_election_message()
{
  packetbuf_clear();
  packetbuf_copyfrom(&node_id, sizeof(node_id));
  broadcast_send(&election_conn);
}

static void send_alive_message()
{
  packetbuf_clear();
  packetbuf_copyfrom(&node_id, sizeof(node_id));
  broadcast_send(&alive_conn);
}

static void send_coordinator_message()
{
  packetbuf_clear();
  packetbuf_copyfrom(&node_id, sizeof(node_id));
  broadcast_send(&coordinator_conn);
}

PROCESS_THREAD(bully_process, ev, data)
{
  static struct etimer et;

  PROCESS_BEGIN();

  node_id = random_rand() % MAX_NODES + 1;
  printf("Node %d started\n", node_id);

  broadcast_open(&election_conn, ELECTION_CHANNEL, &broadcast_call);
  broadcast_open(&alive_conn, ALIVE_CHANNEL, &broadcast_call);
  broadcast_open(&coordinator_conn, COORDINATOR_CHANNEL, &broadcast_call);

  while(1) {
    etimer_set(&et, CLOCK_SECOND * 5);
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));

    if (is_coordinator) {
      send_alive_message();
    } else if (leader_id == -1 || (clock_time() - last_alive_time) > CLOCK_SECOND * 10) {
      // Start election if no leader or leader hasn't sent alive message
      send_election_message();
    }
  }

  PROCESS_END();
}