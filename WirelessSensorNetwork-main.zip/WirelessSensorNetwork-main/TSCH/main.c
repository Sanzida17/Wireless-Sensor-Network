#include "contiki.h"
#include "net/nullnet/nullnet.h"
#include "net/linkaddr.h"
#include "sys/log.h"
#include "sys/node-id.h"
#include "net/netstack.h" 

#define LOG_MODULE "NullNet"
// #define LOG_LEVEL_6LOWPAN LOG_LEVEL_DBG
// #define LOG_LEVEL_NULLNET LOG_LEVEL_DBG
// #define LOG_LEVEL_MAC LOG_LEVEL_DBG
#define LOG_LEVEL LOG_LEVEL_DBG
//#define NETSTACK_NETWORK 1

PROCESS(mesh_under_process, "Mesh-Under Process");
AUTOSTART_PROCESSES(&mesh_under_process);

// Callback function for received packets
void input_callback(const void *data, uint16_t len,
                           const linkaddr_t *src, const linkaddr_t *dest) {
    if (len > 0) {
        LOG_INFO("Received packet '%.*s' from ", len, (char *)data);
        LOG_INFO_LLADDR(src);
        LOG_INFO_("\n");
    } else {
        LOG_INFO("Received empty packet\n");
    }
}

PROCESS_THREAD(mesh_under_process, ev, data) {
    static struct etimer periodic_timer;
    static char message[] = "Hello from node";
    //static linkaddr_t dest_addr;

    PROCESS_BEGIN();
    
    // Initialize the network stack
    netstack_init();
    
    // Initialize NullNet with the input callback function
    //NETSTACK_NETWORK.input(&input_callback);
    nullnet_set_input_callback(&input_callback);

    // Set the destination address (target node)
    //const linkaddr_t target_addr = {{0x00, 0x12, 0x74, 0x05, 0x00, 0x05, 0x05, 0x05}};
    //linkaddr_copy(&dest_addr, &target_addr);

    // Set periodic timer to send packets every 5 seconds
    etimer_set(&periodic_timer, CLOCK_SECOND * 5);

    // if (node_id == 1) {
    //     tsch_set_coordinator(1); // Set this node as coordinator
    //     LOG_INFO("I am the coordinator\n");
    // } else {
    //     LOG_INFO("I am a node\n");
    // }

    while(1) {
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

        // Send message to the specific node
        uint8_t payload[64] = { 0 };
        nullnet_buf = payload; /* Point NullNet buffer to 'payload' */
        nullnet_len = 2; /* Tell NullNet that the payload length is two bytes */
        NETSTACK_NETWORK.output(NULL); /* Send as broadcast */
        LOG_INFO("Sending packet: %s to ", message);
        //LOG_INFO_LLADDR(&dest_addr);
        LOG_INFO_("\n");
        //NETSTACK_NETWORK.output(&dest_addr);

        etimer_reset(&periodic_timer);
    }

    PROCESS_END();
}

// #include "contiki.h"
// //#include "net/rime/rime.h"
// #include "net/mac/tsch/tsch.h"
// #include "sys/log.h"

// #define LOG_MODULE "TSCH Node"
// #define LOG_LEVEL LOG_LEVEL_INFO

// #define SEND_INTERVAL (5 * CLOCK_SECOND)

// static struct broadcast_conn broadcast;
// static struct unicast_conn unicast;

// PROCESS(tsch_node_process, "TSCH Node Process");
// AUTOSTART_PROCESSES(&tsch_node_process);

// static void broadcast_recv(struct broadcast_conn *c, const linkaddr_t *from) {
//     LOG_INFO("Broadcast message received from %d.%d: '%s'\n",
//              from->u8[0], from->u8[1], (char *)packetbuf_dataptr());
// }

// static void unicast_recv(struct unicast_conn *c, const linkaddr_t *from) {
//     LOG_INFO("Unicast message received from %d.%d: '%s'\n",
//              from->u8[0], from->u8[1], (char *)packetbuf_dataptr());
// }

// static const struct broadcast_callbacks broadcast_call = {broadcast_recv};
// static const struct unicast_callbacks unicast_call = {unicast_recv};

// PROCESS_THREAD(tsch_node_process, ev, data) {
//     static struct etimer periodic_timer;
//     linkaddr_t dest_addr;

//     PROCESS_BEGIN();

//     tsch_set_coordinator(1); // Set this node as coordinator if needed

//     broadcast_open(&broadcast, 129, &broadcast_call);
//     unicast_open(&unicast, 146, &unicast_call);

//     etimer_set(&periodic_timer, SEND_INTERVAL);

//     while(1) {
//         PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

//         packetbuf_copyfrom("Hello", 6);
//         linkaddr_copy(&dest_addr, &linkaddr_node_addr);
//         dest_addr.u8[0] += 1; // Example destination address
//         if(!linkaddr_cmp(&dest_addr, &linkaddr_node_addr)) {
//             unicast_send(&unicast, &dest_addr);
//         }

//         etimer_reset(&periodic_timer);
//     }

//     PROCESS_END();
// }

// #include "contiki.h"
// #include "net/mac/tsch/tsch.h"
// #include "net/routing/routing.h"
// #include "net/ipv6/simple-udp.h"
// #include "sys/log.h"

// #define LOG_MODULE "TSCH Node"
// #define LOG_LEVEL LOG_LEVEL_INFO

// #define UDP_PORT 1234
// #define SEND_INTERVAL (5 * CLOCK_SECOND)

// static struct simple_udp_connection udp_conn;

// PROCESS(tsch_node_process, "TSCH Node Process");
// AUTOSTART_PROCESSES(&tsch_node_process);

// static void udp_rx_callback(struct simple_udp_connection *c,
//                             const uip_ipaddr_t *sender_addr,
//                             uint16_t sender_port,
//                             const uip_ipaddr_t *receiver_addr,
//                             uint16_t receiver_port,
//                             const uint8_t *data,
//                             uint16_t datalen) {
//     LOG_INFO("Received message from ");
//     LOG_INFO_6ADDR(sender_addr);
//     LOG_INFO_(": '%.*s'\n", datalen, (char *)data);
// }

// PROCESS_THREAD(tsch_node_process, ev, data) {
//     static struct etimer periodic_timer;
//     uip_ipaddr_t dest_ipaddr;

//     PROCESS_BEGIN();

//     tsch_set_coordinator(1); // Set this node as coordinator if needed
//     simple_udp_register(&udp_conn, UDP_PORT, NULL, UDP_PORT, udp_rx_callback);

//     etimer_set(&periodic_timer, SEND_INTERVAL);

//     while(1) {
//         PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

//         if(NETSTACK_ROUTING.node_is_reachable() && NETSTACK_ROUTING.get_root_ipaddr(&dest_ipaddr)) {
//             char msg[] = "Hello";
//             simple_udp_sendto(&udp_conn, msg, sizeof(msg), &dest_ipaddr);
//             LOG_INFO("Sent message to ");
//             LOG_INFO_6ADDR(&dest_ipaddr);
//             LOG_INFO_("\n");
//         } else {
//             LOG_INFO("Not reachable yet\n");
//         }

//         etimer_reset(&periodic_timer);
//     }

//     PROCESS_END();
// }