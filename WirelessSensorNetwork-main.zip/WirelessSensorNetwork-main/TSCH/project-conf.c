#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_

// Set IEEE 802.15.4 PAN ID (must match across all nodes)
#define IEEE802154_CONF_PANID 0xABCD

// Use TSCH as the MAC layer
#define NETSTACK_CONF_MAC tschmac_driver

// Disable RDC (Radio Duty Cycling) since TSCH handles duty cycling
#define NETSTACK_CONF_RDC nordc_driver

// Enable TSCH logging for debugging purposes
#define TSCH_LOG_LEVEL 3

// Set IEEE 802.15.4 version to 2015 (required for TSCH)
//#define FRAME802154_CONF_VERSION FRAME802154_IEEE802154_2015

#define LOG_CONF_LEVEL_RPL                         LOG_LEVEL_WARN
#define LOG_CONF_LEVEL_TCPIP                       LOG_LEVEL_WARN
#define LOG_CONF_LEVEL_IPV6                        LOG_LEVEL_WARN
#define LOG_CONF_LEVEL_6LOWPAN                     LOG_LEVEL_WARN
#define LOG_CONF_LEVEL_MAC                         LOG_LEVEL_INFO
#define LOG_CONF_LEVEL_FRAMER                      LOG_LEVEL_WARN
#define TSCH_LOG_CONF_PER_SLOT                     0

#endif /* PROJECT_CONF_H_ */