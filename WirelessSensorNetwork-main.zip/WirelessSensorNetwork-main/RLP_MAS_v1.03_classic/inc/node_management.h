#ifndef NODE_MANAGEMENT_H
#define NODE_MANAGEMENT_H

#ifdef VM_ENV  // Virtual Machine environment (defined in Makefile) by adding ENV=vm
    #pragma message("Virtual Machine environment")
    #include "net/ipv6/simple-udp.h"
    #include "net/routing/rpl-classic/rpl.h"
    #include "sys/node-id.h"
    #define ROUTING_CONF_RPL_CLASSIC    1
#elif defined(PC_ENV)  // Physical Linux PC environment (defined in Makefile) by adding ENV=linux
    #pragma message("Linux environment")
    #include "net/ip/simple-udp.h"
    #include "net/rpl/rpl.h" // Hvae to figure out how to use RPL-lite instead here as well. This gives errors for VM
    #include "sys/node-id.h"
#else 
    #error "Unknown environment! Please specify ENV_TYPE as 'vm' or 'linux'."
#endif


#include "contiki.h"
#include "simple-udp.h"
#include "inc/types.h"
#include "inc/bully.h"
#include "inc/energy.h"
#include "inc/logs.h"
#include "inc/network_msg.h"
#include "inc/timer_helper.h"

#define LEADER 1

//extern struct simple_udp_connection conn;

// Assuming rx_callback is defined in network_msg.h
extern void rx_callback(struct simple_udp_connection *c,
                        const uip_ipaddr_t *sender,
                        uint16_t port,
                        const uip_ipaddr_t *receiver,
                        uint16_t recv_port,
                        const uint8_t *data,
                        uint16_t len);


//void decrease_and_log_energy(election_data_t *election_data);

//void node_actions(election_data_t *election);

void start_listening(struct simple_udp_connection *conn, node_t *node, struct etimer *timer);

void setupCooridnator(election_data_t *election_data, timer_data_t *timer); 

//bool is_low_energy_coordinator(const election_data_t *election_data);

// Function to handle regular coordinator actions and trigger elections if needed
void step_down_as_coordinator(election_data_t *election_data);

bool is_orphan(election_data_t *election_data);

bool is_member(election_data_t *election_data);

void should_start_election(election_data_t *election_data, const timer_data_t *timer_data);

void decide_node_type(election_data_t* election_data, timer_data_t *timer_data);

#endif /* NODE_MANAGEMENT_H */