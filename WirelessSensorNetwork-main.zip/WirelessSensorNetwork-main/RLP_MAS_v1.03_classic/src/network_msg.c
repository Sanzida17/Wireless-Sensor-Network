
#include "inc/network_msg.h"
#include <stdio.h>

// extern uint8_t num_nodes;
// extern uint8_t active_nodes[MAX_NODES];

void send(uint16_t to, msg_t *msg) {
    LOG_INFO("Sending message to %d\n", to);
    uip_ipaddr_t addr;
    uip_ip6addr(&addr, 0xaaaa, 0, 0, 0, 0, 0, 0, to);
    simple_udp_sendto(&conn, msg, sizeof(msg_t), &addr);
}

// Can we make the forloop reversed
// Does we assmume the id is unique and is 1 to 255?
void broadcast(MSG type, uint16_t start, uint16_t end, node_t *node) {  
    // THIS WORKS IN COOJA DUE TO NODE IS NAMED 1 AND SO ON. 
    // NEED A LIST TO CONNTROL ON RELAITY
    msg_t msg = {
                .type = type,
                .meta = { .sender_id = node->id, .sender_energy = ENERGY_STARTINGPOINT } // Should be own energy source?
    };

    for (size_t i = start; i <= end; i++) {
        if (i != node->id) {
            send(i, &msg);
        }
    }

    // for (size_t i = 0; i < num_nodes; i++) {
    //     if (active_nodes[i] != node.id) {
    //         send(active_nodes[i], &msg);
    //     }
    // }
}

void rx_callback(struct simple_udp_connection *c,
                 const uip_ipaddr_t *sender,
                 uint16_t port,
                 const uip_ipaddr_t *receiver,
                 uint16_t recv_port,
                 const uint8_t *data,
                 uint16_t len) {
    LOG_INFO("Received message from %d\n", sender->u8[sizeof(uip_ipaddr_t) - 1]);

    if(len != sizeof(msg_t)) return;

    container_t *content = (container_t *)data;
    msg_t *msg = content->msg;
    election_data_t *election_data = content->election_data;
    timer_data_t *timer = content->timer;

    switch (msg->type) {
        case MSG_ELECTION:
            handle_msg_election(msg, election_data, timer);
            break;

        case MSG_OK:
            handle_msg_ok(msg, election_data);
            break;

        case MSG_COORDINATOR:
            handle_msg_coordinator(msg, election_data, timer);
            break;

        case MSG_HEART:
            handle_msg_heart(msg, election_data, timer);
            break;

        default:
            LOG_WARN("Unknown message type: %d\n", msg->type);
            break;
    }
}