# Commands
```
make TARGET=native main.native
```

```
make TARGET=sky motelist
```


```
make TARGET=sky MOTES=/dev/ttyUSB0 main.upload
```

Faster built for lib files
```
make -j 20 TARGET=sky MOTES=/dev/ttyUSB0 main.upload 
```

```
make TARGET=sky MOTES=/dev/ttyUSB0 login
```
                                    