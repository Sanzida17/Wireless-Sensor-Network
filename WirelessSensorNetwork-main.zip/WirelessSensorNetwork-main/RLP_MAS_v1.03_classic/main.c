#include <stdio.h>



#include "inc/bully.h"
#include "inc/election.h"
#include "inc/energy.h"
#include "inc/logs.h"
#include "inc/messages.h"
#include "inc/network_msg.h"
#include "inc/node_management.h"
#include "inc/status_strings.h"
#include "inc/sensors_helper.h"
#include "inc/timer_helper.h"
#include "inc/types.h"
#include "lib/random.h"

PROCESS(bully_process, "Bully");
AUTOSTART_PROCESSES(&bully_process);

election_data_t election_data;
timer_data_t timer_data;
measurements_t measurements;

static struct etimer timer;
static struct ctimer e_timer;

struct simple_udp_connection conn;
// uint8_t num_nodes = /* Initialize with the number of nodes */;
// uint8_t active_nodes[MAX_NODES] = { /* Initialize with active node IDs */ };

PROCESS_THREAD(bully_process, ev, data) {
    PROCESS_BEGIN();

    random_init((unsigned short)node_id);
    election_data.node.id = node_id; // Assign appropriate node_id
    election_data.coordinator.id = 0; 
    election_data.coordinator.status = ABSENT;
    election_data.node.energy = MIN_RANDOM + (random_rand() % (MAX_RANDOM - MIN_RANDOM + 1));;
    election_data.type = ORPHAN;
    election_data.election = ELECTION_NONE;
    election_data.received = RECEIVED_NO;
    election_data.currentState = INIT_NODE_TYPE;

    timer_data.timer = &timer;
    timer_data.e_timer = &e_timer;
    timer_data.heartbeat = clock_time();
    SENSORS_ACTIVATE(sht11_sensor);
    
    while(1) {
        switch (election_data.currentState)
        {
        case INIT_NODE_TYPE:
            LOG_INFO("[N%d] STATE Deciding Node Type... (E:%d)\n", election_data.node.id, election_data.node.energy);
            decide_node_type(&election_data, &timer_data);
            break;    

        case STATE_MEMBER_NODE_START_LISTING:
            LOG_INFO("[N%d] STATE Start Node Listen... (E:%d)\n", election_data.node.id, election_data.node.energy);
            start_listening(&conn, &election_data.node, timer_data.timer);
            election_data.currentState = STATE_MEMBER_IDLE;
            break;
        
        case STATE_COORDINATOR_INITIAL_SETUP:
            LOG_INFO("[N%d] STATE Coordinator Initialises... (E:%d)\n", election_data.node.id, election_data.node.energy);
            setupCooridnator(&election_data, &timer_data);
            set_coordinator(&election_data);
            start_listening(&conn, &election_data.node, timer_data.timer);
            break;

        case STATE_COORDINATOR_SET_NEW_NODE:
            // How to set new coordinator?
            break;

        case STATE_COORDINATOR_ACTION:
            LOG_INFO("[N%d] STATE Coordination Action... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_low_energy(&election_data))
                step_down_as_coordinator(&election_data);
            break;

        case STATE_MEMBER_IDLE:
            LOG_INFO("[N%d] STATE Member... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_orphan(&election_data))
                break;

            // READ DATA FROM SENSORS
            readSensors(&measurements);
            // SEND DATA 
            measurements.temperature = convertToCelsius(measurements.temperature);
            measurements.humidity = convertToHumidity(measurements.humidity);
            log_scaled_value("Temperature", measurements.temperature, "°C");
            log_scaled_value("Humidity", measurements.humidity, "%");
            break;

        case STATE_ORPHAN_IDLE:
            LOG_INFO("[N%d] STATE Orphan... (E:%d)\n", election_data.node.id, election_data.node.energy);
            if (is_member(&election_data))
                should_start_election(&election_data, &timer_data);
            break;

        case STATE_NODE_START_ELECTION:
            LOG_INFO("[N%d] STATE Election: Starting election... (E:%d)\n", election_data.node.id, election_data.node.energy);
            start_election(&election_data, &timer_data);
            break;

        case ENERGY_LOW:
            LOG_INFO("[N%d] STATE Energy Low... (E:%d)\n", election_data.node.id, election_data.node.energy);

            break;
        case ENERGY_GONE:
            //LOG_INFO("[N%d] STATE Energy Gone...\n", election_data.node.id);
            break;

        default:
            LOG_WARN("[N%d] Unknown state: %d\n", election_data.node.id, election_data.currentState);
            break;
        }

        decrease_energy(&election_data);
     
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(timer_data.timer));
        //etimer_reset(timer_data.timer);
        // Reset the main event timer if expired
        etimer_reset(timer_data.timer);
    }
    
    PROCESS_END();
}

